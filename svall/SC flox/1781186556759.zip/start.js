console.clear();
require('./config');
const { 
    default: makeWASocket, 
    prepareWAMessageMedia, 
    useMultiFileAuthState, 
    DisconnectReason,
    fetchLatestBaileysVersion, 
    makeInMemoryStore, 
    generateWAMessageFromContent, 
    generateWAMessageContent, 
    generateWAMessage,
    jidDecode, 
    proto, 
    delay,
    relayWAMessage, 
    getContentType, 
    getAggregateVotesInPollMessage, 
    downloadContentFromMessage, 
    fetchLatestWaWebVersion, 
    InteractiveMessage, 
    makeCacheableSignalKeyStore, 
    Browsers, 
    generateForwardMessageContent, 
    MessageRetryMap 
} = require('@whiskeysockets/baileys');

const pino = require('pino');
const FileType = require('file-type');
const readline = require("readline");
const fs = require('fs');
const crypto = require("crypto");
const path = require('path'); 
const { spawn } = require('child_process');
const chalk = require('chalk');
const yargs = require("yargs/yargs");
const axios = require("axios");
const { Boom } = require('@hapi/boom');
const { toAudio, toPTT, toVideo } = require('./library/converter.js');
const { color } = require('./library/color');
const { smsg, sleep, getBuffer } = require('./library/myfunction');
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./library/exif');

const usePairingCode = true;

const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise(resolve => rl.question(text, answer => { rl.close(); resolve(answer); }));
};

const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

console.clear();
console.log(chalk.cyan(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⠄⠀⡐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡈⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠄⠀⠀⠀⠀⠈⠙⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⡶⠦⣠⣀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠈⣟⠲⡎⠙⢦⠈⢧
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡰⢃⡠⠋⣠⠋
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠄⢂⠀⠀⠀⠀⠀⣀⣠⠠⢖⣋⡥⢖⣩⠔⠊⠀⠀
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣨⠭⢵⣒⣩⠬⢖⠏⠁⢀⣀⠀⠀⠀
⠀⠀⠈⠓⠒⠦⠍⠭⠭⣭⠭⠭⠭⠭⡿⡓⠒⠛⠉⠉⠀⠀⣠⠇⠀⠀⠘⠞⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠁⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠉⠉⠙⠒⠒⠚⠉⠁⠀⠀⠀⠁⢣⡎⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
`));
console.log(chalk.blue.bold(`Owner : \nDeveloper : FiiXyz\nVersion : 1 VIP\n`));

async function StartBot() {
    const { state, saveCreds } = await useMultiFileAuthState("session");
    const FiiXyz = makeWASocket({
        printQRInTerminal: !usePairingCode,
        syncFullHistory: true,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true,
        patchMessageBeforeSending: (message) => {
            if (message.buttonsMessage || message.templateMessage || message.listMessage) {
                message = { viewOnceMessage: { message: { messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} }, ...message } } };
            }
            return message;
        },
        version: (await (await fetch('https://raw.githubusercontent.com/Itsukichann/Baileys/refs/heads/master/lib/Defaults/baileys-version.json')).json()).version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({ level: 'fatal' }),
        auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'silent', stream: 'store' })) }
    });

    // Password 
    const manualPassword = 'fii hanya just freind';

    if (usePairingCode && !FiiXyz.authState.creds.registered) {
        const inputPassword = await question('Masukkan Password:\n');
        if (inputPassword !== manualPassword) {
            console.log(chalk.cyan.bold(`PASSWORD SALAH! AKSES DITOLAK`));
            process.exit(0);
        }

        console.log(chalk.blue.bold(`Password benar! Lanjut ke pairing`));
        const phoneNumber = await question('Masukkan Nomor Kamu (contoh: 62xxx):\n');
        const BotNumber = phoneNumber.trim();
        
        const code = await FiiXyz.requestPairingCode(BotNumber, "FIIXYZZZ");
        console.log(chalk.cyan.bold(`\nKODE PAIRING ANDA ADALAH: `) + chalk.white.bold(code) + `\n`);
    }

    store.bind(FiiXyz.ev);
    
    FiiXyz.ev.on("messages.upsert", async (chatUpdate) => {
        try {
            const mek = chatUpdate.messages[0];
            if (!mek.message) return;
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message;
            if (mek.key && mek.key.remoteJid === 'status@broadcast') return;
            
            const m = smsg(FiiXyz, mek, store);

            const isCreator = [FiiXyz.user.id, ...global.owner]
                .map(v => v.replace(/[^0-9]/g,'')+'@s.whatsapp.net')
                .includes(m.sender);

            if (!FiiXyz.public && !mek.key.fromMe && !isCreator) return;
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;
            if (mek.key.id.startsWith('kelpinDeveloper')) return;
            
            require("./Fiixyz.js")(FiiXyz, m, chatUpdate, store);
        } catch (err) {
            console.log(err);
        }
    });

    FiiXyz.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    FiiXyz.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = FiiXyz.decodeJid(contact.id);
            if (store && store.contacts) store.contacts[id] = { id, name: contact.notify };
        }
    });

    global.idch1 = "120363410663131872@newsletter"; //ch Fiixyz
    global.idch2 = "120363427151558096@newsletter"; //ch Fiixyz
    global.idch3 = "120363406735306867@newsletter"; //ch Fiix

    
    FiiXyz.public = global.publik;

    FiiXyz.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            if (lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut) {
                StartBot();
            }
        } 
        else if (connection === 'open') {
            console.log(chalk.green.bold('FLOX SUCCESS CONNECTED TO SERVER 🤓'));
            FiiXyz.newsletterFollow(global.idch1);
            FiiXyz.newsletterFollow(global.idch2);
            FiiXyz.newsletterFollow(global.idch3);
            FiiXyz.newsletterFollow(global.idch4);
            FiiXyz.newsletterFollow(global.idch5);
            FiiXyz.newsletterFollow(global.idch6);
            FiiXyz.newsletterFollow(global.idch7);
            FiiXyz.newsletterFollow(global.idch8);
        }
    });

    FiiXyz.ev.on('group-participants.update', async (update) => {
        const { id, author, participants, action } = update;
        try {
            global.db = global.db || {};
            global.db.groups = global.db.groups || {};
            global.db.groups[id] = global.db.groups[id] || { welcome: true };
            if (!global.db.groups[id].welcome) return;
            const metadata = await FiiXyz.groupMetadata(id);
            for (let n of participants) {
                let teks = "";
                const user = `@${n.split('@')[0]}`;
                const pelaku = author ? `@${author.split('@')[0]}` : "Sistem";
                if (action === 'add') {
                    teks = !author ? `Selamat datang ${user} di grup ${metadata.subject}. Harap membaca deskripsi grup sebelum berinteraksi.` : `${pelaku} telah menambahkan ${user}. Beban grup sekarang bertambah satu.`;
                } else if (action === 'remove') {
                    teks = author === n ? `${user} telah keluar dari grup sekarang beban grup sudah berkurang satu.` : `${user} telah dikeluarkan oleh ${pelaku}. Sekarang beban grup telah musnah satu dari grup`;
                } else if (action === 'promote') {
                    teks = `${user} telah diangkat menjadi admin oleh ${pelaku}.`;
                } else if (action === 'demote') {
                    teks = `${user} telah diturunkan dari jabatan admin oleh ${pelaku}.`;
                }
                if (!teks) continue;
                await FiiXyz.sendMessage(id, { text: teks, contextInfo: { mentionedJid: author ? [author, n] : [n] } }, { quoted: { key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: 'status@broadcast' }, message: { conversation: '𝐅𝐋𝐎𝐗 𝐕𝟏' } } });
            }
        } catch (err) { console.log("Group Update Error:", err) }
    });

    FiiXyz.sendText = async (jid, text, quoted = '', options) => {
        FiiXyz.sendMessage(jid, { text: text, ...options }, { quoted });
    };
    
    FiiXyz.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
        let type = await FiiXyz.getFile(path, true);
        let { res, data: file, filename: pathFile } = type;
        if (res && res.status !== 200 || file.length <= 65536) {
            try { throw { json: JSON.parse(file.toString()) } } catch (e) { if (e.json) throw e.json }
        }
        let opt = { filename };
        if (quoted) opt.quoted = quoted;
        if (!type) options.asDocument = true;
        let mtype = '', mimetype = type.mime, convert;
        if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
        else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
        else if (/video/.test(type.mime)) mtype = 'video';
        else if (/audio/.test(type.mime)) (
            convert = await (ptt ? toPTT : toAudio)(file, type.ext),
            file = convert.data, pathFile = convert.filename, mtype = 'audio', mimetype = 'audio/ogg; codecs=opus'
        );
        else mtype = 'document';
        if (options.asDocument) mtype = 'document';
        let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
        let m;
        try { m = await FiiXyz.sendMessage(jid, message, { ...opt, ...options }) } catch (e) { m = null } finally {
            if (!m) m = await FiiXyz.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
            return m;
        }
    };

    FiiXyz.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || '';
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]) }
        return buffer;
    };

    FiiXyz.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`, `[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifImg(buff, options) : await addExif(buff);
        await FiiXyz.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };
    
    FiiXyz.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message;
        let mime = (message.msg || message).mimetype || "";
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0];
        const stream = await downloadContentFromMessage(quoted, messageType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]) }
        let type = await FileType.fromBuffer(buffer);
        let trueFileName = attachExtension ? filename + "." + type.ext : filename;
        await fs.writeFileSync(trueFileName, buffer);
        return trueFileName;
    };

    FiiXyz.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`, `[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0);
        let buffer = options && (options.packname || options.author) ? await writeExifVid(buff, options) : await videoToWebp(buff);
        await FiiXyz.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
        return buffer;
    };

    FiiXyz.albumMessage = async (jid, array, quoted) => {
        const album = generateWAMessageFromContent(jid, {
            messageContextInfo: { messageSecret: crypto.randomBytes(32) },
            albumMessage: {
                expectedImageCount: array.filter((a) => a.hasOwnProperty("image")).length,
                expectedVideoCount: array.filter((a) => a.hasOwnProperty("video")).length,
            },
        }, { userJid: FiiXyz.user.jid, quoted, upload: FiiXyz.waUploadToServer });
        await FiiXyz.relayMessage(jid, album.message, { messageId: album.key.id });
        for (let content of array) {
            const img = await generateWAMessage(jid, content, { upload: FiiXyz.waUploadToServer });
            img.message.messageContextInfo = {
                messageSecret: crypto.randomBytes(32),
                messageAssociation: { associationType: 1, parentMessageKey: album.key },
                participant: "0@s.whatsapp.net", remoteJid: "status@broadcast", forwardingScore: 99999, isForwarded: true, mentionedJid: [jid], starred: true, labels: ["Y", "Important"], isHighlighted: true, businessMessageForwardInfo: { businessOwnerJid: jid }, dataSharingContext: { showMmDisclosure: true }
            };
            img.message.forwardedNewsletterMessageInfo = { newsletterJid: "0@newsletter", serverMessageId: 1, newsletterName: `WhatsApp`, contentType: 1, timestamp: new Date().toISOString(), senderName: "✧ Dittsans", content: "Text Message", priority: "high", status: "sent" };
            img.message.disappearingMode = { initiator: 3, trigger: 4, initiatorDeviceJid: jid, initiatedByExternalService: true, initiatedByUserDevice: true, initiatedBySystem: true, initiatedByServer: true, initiatedByAdmin: true, initiatedByUser: true, initiatedByApp: true, initiatedByBot: true, initiatedByMe: true };
            await FiiXyz.relayMessage(jid, img.message, { messageId: img.key.id, quoted: { key: album.key, message: album.message } });
        }
        return album;
    };
    
    FiiXyz.sendStatusMention = async (content, jids = []) => {
        let users;
        for (let id of jids) {
            let userId = await FiiXyz.groupMetadata(id);
            users = await userId.participants.map(u => FiiXyz.decodeJid(u.id));
        };
        let message = await FiiXyz.sendMessage("status@broadcast", content, {
            backgroundColor: "#000000", font: Math.floor(Math.random() * 9), statusJidList: users,
            additionalNodes: [{ tag: "meta", attrs: {}, content: [{ tag: "mentioned_users", attrs: {}, content: jids.map((jid) => ({ tag: "to", attrs: { jid }, content: undefined })) }] }]
        });
        jids.forEach(id => {
            FiiXyz.relayMessage(id, { groupStatusMentionMessage: { message: { protocolMessage: { key: message.key, type: 25 } } } }, { userJid: FiiXyz.user.jid, additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }] });
            delay(2500);
        });
        return message;
    };

    FiiXyz.ev.on('creds.update', saveCreds);
    return FiiXyz;
}

StartBot();

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m');
    delete require.cache[file];
    require(file);
});
