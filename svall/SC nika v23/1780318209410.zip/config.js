const fs = require('fs')

// Settings Bot
global.owner = ["628814595506", "6283192054753"]
global.namaowner = "depayy"
global.publik = true
global.prefa = ["!", ".", ",", "🐤", "🗿"];

// Settings Panel Pterodactyl 
global.egg = "15"; // Egg ID
global.nestid = "5"; // Nest ID
global.loc = "1"; // Location ID
global.domain = "";
global.apikey = ""; // PTLC
global.capikey = ""; // PTLA

// Global Mess
global.mess = {
	owner: `*❌ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI*`,
	admin: `*❌ HANYA ADMIN GROUP YANG BISA MENGGUNAKAN FITUR INI*`,
	botAdmin: `*❌ BOT HARUS JADI ADMIN TERLEBIH DAHULU*`,
	group: `*❌ FITUR INI HANYA BERLAKU DI GROUP*`,
	private: `*❌ FITUR INI HANYA BERLAKU DI PRIVATE CHAT*`,
	murbug: `*❌ FITUR INI HANYA UNTUK USER PREMIUM*`
}
// Global Nama Sticker
global.packname = ' '
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'

// End Settings
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
